%% CSC 262 lab: Edge Detection
%
% CSC 262

%% Introduction
% This lab explores different ways of analyzing edges in a picture. It
% begins with finding the horizontal and vertical partial derivatives of
% an image. We use these to determine the magnitude of the gradient at each
% pixel. We also use these partial derivatives to determine the direction
% of the gradient by applying atan2 and using a color map. 
%%
% The second half of the lab is spent repeating this process so it can be
% iterative. We iterate with different sizes for our gaussian kernel and
% also iterate with different thresholds for the gradient magnitude image.
% In total, this was 25 iterations, and we found that conservative kernel
% sizes and thresholds are a necessity, as only 6 of the 25 iterations 
% marked any edges. The magnitude image grew fainter with increased kernel
% size, and the orientation became blurrier.

%% Process 

img = im2double(imread('/home/weinman/courses/CSC262/images/bug.png'));
gauss = gkern(4,0); % create a 1-d gaussian kernel with variane 4
dgauss = gkern(4,1); % 1st order gaussian kernel
convImgR = conv2(gauss, dgauss, img, 'valid');
convImgC = conv2(dgauss, gauss, img, 'valid');

subplot(1, 3, 2);
imshow(convImgR, []);
title("Row Derivative");
subplot(1, 3, 3);
imshow(convImgC, []);
title("Column Derivative");
subplot(1, 3, 1);
imshow(img);
title("Original Image");

% a5:
%%
% Above we show our original image of a caterpillar and the partial
% derivatives of the image with respect to brightness. The row and column
% derivative images above are bright where the original image increases in
% gray-scale level moving in the left-to-right and top-to-bottom
% directions, respectively. This happens between the black and white parts
% of the catapillar and between the stem and the catapillar. Increasing
% pixel brightness will make the derivative positive and thus bright in the
% derivative image. Decreasing pixel brightness will make the derivative
% negative and thus dark in the derivative image. Relatively constant
% brightnesses will give a derivative near zero and are grey in the
% derivative image.
%%
% Notice that the row image clearly marks the stem while the column image
% does not. This is because the stem is a nearly vertical line, so it is
% relatively constant moving from top-to-bottom over the stem. On the other
% hand, there is a clear chance moving across the stem in the left-to-right
% direction, so it appears in that image.


%B
magImg = convImgR.^2 + convImgC.^2;
magImg = sqrt(magImg);
magImg2 = magImg;
magImg2(magImg2<.02) = 0;
magImg2(magImg2>.02) = 1;

subplot(1, 2, 1);
imshow(magImg, []);
title("Gradient Magnitude Image");
subplot(1, 2, 2);
imshow(magImg2);
title("Detection Image");
%b2
%%
% Combinging our partial derivatives to find the magnitude at each pixel,
% we produce the Gradient Magnitude Image above. We combined them by
% squaring the value of each partial derivative at that pixel, summing
% them, and then taking a square root. Since the magnitude equation
% eliminates negatives, what shine through in the Gradient Magnitude Image
% are the areas of change in brightness from the original image. Displaying
% the image again but with all values above 5 gray-scales set to white and
% everything below set to black, we get the detection image on the right.
% The value of this gradient magnitude image is that the white areas it
% produces are in fact the edges of the original image. 

%C
direcImg = atan2(convImgR, convImgC);
figure;
imshow(direcImg, [-pi, pi]);
title("Directional Gradient Image");
colormap(hsv);
colorbar;
%%
% The directional gradient image above is a lot to digest visually.
% The ranges are produced by tan^-1, so we can determine the direction
% based off only the color shown. The cyan all corresponds to the gradient
% pointing to the right. The bright red tones around pi and negative pi
% both correspond to the gradient pointing left. The green and yellow tones
% both generally correspond to pointing upwards, but those ranges also
% include point down to the right and down to the left (or the "diagonals").
% Finally, the blue and purple ranges, much like the green and yellow,
% include gradients point up, up to the left, and up to the right.
% One issue with the image though, and part of what makes it so hard to
% interpret, is that the color display is equally vibrant in all parts of
% the image. That means that the edges around the caterpillar which we want
% to examine are shown just as much as small changes in the background
% which are not important. 


%D
%d6

hueImg = (direcImg + pi)/(2*pi);
satImg = magImg/max(magImg, [], 'all');
valueImg = ones(size(direcImg));

hsvImg = cat(3, hueImg, satImg, valueImg);
rgbImg = hsv2rgb(hsvImg);
figure;
imshow(rgbImg);
title("Orientation Image");
%%
% To mitigate the issues with the directional gradient image, we create an
% HSV colorspace. HSV stands for hue, saturation, and value, and Matlab can
% convert this colorspace to our typical rgb easily. With this method, we
% see our new Orientation Image only displays the orientation around the
% edges of the caterpillar (which is what we want). This gives us a much
% better idea of the gradient where there are large changes actually taking
% place.


gradMagArr = zeros(size(img));
gradMagArr(1:end,1:end,1,1:5) = 0;
wOrientArr = zeros(size(img));
wOrientArr(1:end,1:end,1:3,1:5) = 0;
tkArr = zeros(size(img));
tkArr(1:end, 1:end, 1:5, 1:5) = 0;
[standREnd, standCEnd] = size(img);

for i = 1:5
     m = 2^(i-1);
     fGauss = gkern(m);
     fDGauss = gkern(m, 1);
     fConvImgR = conv2(fGauss, fDGauss, img, 'valid');
     fConvImgC = conv2(fDGauss, fGauss, img, 'valid');
     fmagImg = fConvImgR.^2 + fConvImgC.^2;
     fmagImg = sqrt(fmagImg);
     
     [thisREnd, thisCEnd] = size(fmagImg);
     
     %Thresholds
     for c = 1:5
         thresholds = [24.0 32.0 48.0 64.0 96.0];
         tkMag = fmagImg;
         tkMag(tkMag<(thresholds(c)/256)) = 0;
         tkMag(tkMag>=(thresholds(c)/256)) = 1;
         
         tkMag(thisREnd:standREnd, :) = 0;
         tkMag(:, thisCEnd:standCEnd) = 0;
         
         tkArr(:,:, c,i) = tkMag;
     end
     
     fdirecImg = atan2(fConvImgR, fConvImgC);
     fhueImg = (fdirecImg + pi)/(2*pi);
     fsatImg = fmagImg/max(fmagImg, [], 'all');
     fvalueImg = ones(size(fdirecImg));
     
     fmagImg(thisREnd:standREnd, :) = 0;
     fmagImg(:, thisCEnd:standCEnd) = 0;
     
     fhueImg(thisREnd:standREnd, :) = 0;
     fhueImg(:, thisCEnd:standCEnd) = 0;
     fsatImg(thisREnd:standREnd, :) = 0;
     fsatImg(:, thisCEnd:standCEnd) = 0;
     fvalueImg(thisREnd:standREnd, :) = 0;
     fvalueImg(:, thisCEnd:standCEnd) = 0;
     
     fhsvImg = cat(3, fhueImg, fsatImg, fvalueImg);
     frgbImg = hsv2rgb(fhsvImg);
     
     wOrientArr(:,:,:,i) = frgbImg;
     gradMagArr(:,:,:,i) = fmagImg;
     
end
newArr = reshape(tkArr,352,264,1,25);

%% Here are our Orientation Images:
montage(wOrientArr,'Size',[1 5]);
title("Orientation Images with Increasing Kernel Size");
%% Here are our Magnitude Images:
montage(gradMagArr, 'Size', [1 5]);
title("Magnitude Images with Increasing Kernel Size");
%%
% We created the same magnitude and orientation images as we did earlier in
% the lab but using multiple different kernel sizes. Above you may see the
% images produced when Gaussian variances 1, 2, 4, 16, and 32,
% respectively. As you can see the images get smaller with the larger
% variance. Additionally, the magnitude image grows dimmer and the
% lines of the orientation image grow and become fuzzier. This makes sense
% as our kernel is calculating change over a larger area, making that
% change spread out and decrease in magnitude.


%% Here are our Magnitude Images with Increasing Thresholds:
montage(newArr,'Size',[5 5]);
title("Magnitude Images with Increasing Kernel Size & Threshold");

%% 
% The detection images above disappear with either increase in kernel size
% or threshold. Out of the 25 images produced, only 6 of them have any
% detections. These 6 are in the top left corner. They correspond to the
% inputs x = Gaussian Variance and y = threshold of (1, 24/256), (1,
% 32/256), (1, 48/256), (2, 24/256), (2, 32/256), and (3, 24/256). On the
% plot, moving across the columns correspond to change in kernel size while 
% moving down the rows correspond to change in threshold. We see that
% increasing thresholds and increasing varriance will both 
% diminish detection. As discussed above, increasing variance means that we
% calculate the derivative over a larger area, decreasing the magnitude,
% and meaning that the same threshold will have a larger affect with a
% larger variance. 


%% Conclusion
% This lab explored the role of deriviatives and gradients in an image. We
% found that the gradient was an extremely useful way of finding edges. We
% also determined the direction of the gradient, and when this was applied
% to the edges, the orientation image showed all the spots where brightness
% change and in what direction. Repeating this as an iterative process, we
% found that larger Gaussian variances made the edges in the orientation
% image much larger and fuzzier. The detection image also fails to detect
% when either Gaussian variance or detection threshold increase. 


%% Acknowledgement
% The raw pictures are provided by MatLab.
%
% The Matlab markup guide: https://www.mathworks.com/help/matlab/matlab_prog/marking-up-matlab-comments-for-publishing.html
%
% Code are from the lab manual page: https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/edges.html