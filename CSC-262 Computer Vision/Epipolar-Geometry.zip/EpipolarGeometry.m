%% CSC 262 Lab: Epipolar Geometry
%
% CSC 262

%% Overview
% In this lab, we will plot the epipoles and epipolar lines in an image
% pair using a fundamental matrix. We will get this result by finding the
% correspondences manually and applying the singular value decomposition
% (SVD). We eventually plot the epipolar lines with an offset of 35 pixels
% and find they intersect outside the image.

%% Picking Correspondences
% We pick our correspondences manually from both images by matching
% specific points on the left image with the corresponding feature on the
% right image. The results are displayed with a plus as shown below. 

leftImg = imread('/home/weinman/courses/CSC262/images/left.png');
rightImg = imread('/home/weinman/courses/CSC262/images/right.png');

figure(1);
title('Left Image');
imshow(leftImg);

figure(2);
title('Right Image');
imshow(rightImg);

% leftxCords = zeros(8,1);
% rightxCords = zeros(8,1);
% leftyCords = zeros(8,1);
% rightyCords = zeros(8,1);
% 
% for i = 1:8
%     figure(1);
%     [leftX, leftY] = ginput(1);
%     leftxCords(i)= leftX;
%     leftyCords(i) = leftY;
%     hold on;
%     plot(leftX,leftY, '+');
%     
%     pause(0.05);
%     
%     figure(2);
%     [rightX, rightY] = ginput(1);
%     rightxCords(i) = rightX;
%     rightyCords(i) = rightY;
% end

% Saving the coordinates in two files
%save('leftCords.mat', 'leftxCords', 'leftyCords')
%save('rightCords.mat', 'rightxCords', 'rightyCords')
load('leftCords.mat');
load('rightCords.mat');

figure(1);
hold on;
title('Correspondences on the left image');
plot(leftxCords,leftyCords,"+");
pause(.5);

figure(2);
title('Correspondences on the right image');
hold on;
plot(rightxCords, rightyCords, "+");
pause(.5);
%% Constructing the fundamental matrix 
% Using the correspondences we have picked, we can estimate our fundamental
% matrix. This is first achieved by getting the 8x9 system matrix based on
% our 8 correspondences. Afterwards, we apply single value decomposition to
% the system matrix to get V which we can then reshape into the initial
% estimate of the fundamental matrix.


% Set the number of correspondence points
p = 8;
xl = leftxCords;
xr = rightxCords;
yl = leftyCords;
yr = rightyCords;

sysMatrix = [xl.*xr, xl.*yr, xl, yl.*xr, yl.*yr, yl, xr,yr, ones(p,1)];

[U, W, V] = svd(sysMatrix);
smallestV = V(:,size(V,1));
reshapedV = reshape(smallestV, [3,3]);

%% 
% The rank of the reshape matrix is:
rank(reshapedV)

[U1, W1, V1] = svd(reshapedV);
W1(3,3) = 0;

%%
% We find that the singular values of this initial fundamental matrix are
% 1, 6.95*10^(-5), and 3.79*10^(-8). Singular values are derived by taking
% the square root of the eigenvalues. We expect the non-zero singular
% values of the essential matrix to be the same. These two non-zero values
% construct the epipolar lines in the format of ax+by+c. Notice that this
% matrix corresponds to the normalized image coordinate we picked.  The
% effective image focal length is 1.

FundamentalMatrix = U1*W1*V1';

%%
% The rank of the fundamental matrix is:
rank(FundamentalMatrix)

%% Visualizing Epipolar lines

%%
% Now that we have the estimated fundamental matrix, it is possible to get
% pick a point on an image and get its respective epipolar line in the
% other image. We shall do this in both directions by picking a point in
% the left image then plot out its corresponding epipolar line in the right
% image and vice versa.

% Getting the left and right column as x coordinates
x1 = 1;
x2 = size(leftImg, 2);
% Calculate the corresponding x coordinate in the right image

figure(1);
%[leftX1, leftY1] = ginput(1);

% Saving the point on the left image we have saved and load it for the
% lab writeup.
% save('D1cords.mat', 'leftX1', 'leftY1');
load('D1cords.mat');
hold on;
title('Left Image with extra correspondences');
plot(leftX1,leftY1, '+');

pause(0.05);

figure(2);
title('Right Image with corresponding epipolar line');

hold on;
newPoint = [leftX1, leftY1, 1];
ur = FundamentalMatrix*newPoint';
y1 = -(ur(1)*x1 + ur(3))/ur(2);
y2 = -(ur(1)*x2 + ur(3))/ur(2);
plot([x1 x2], [y1 y2]);
pause(.5);

% D2
figure(2);
%[rightX1, rightY1] = ginput(1);

% Saving the point on the left image we have saved and load it for the
% lab writeup.
% save('D2cords.mat', 'rightX1', 'rightY1');
load('D2cords.mat');
hold on;
plot(rightX1,rightY1, '+');
title('Right Image with extra correspondences');

pause(0.05);

figure(1);
hold on;
newPoint = [rightX1, rightY1, 1];
ur = FundamentalMatrix*newPoint';
y1 = -(ur(1)*x1 + ur(3))/ur(2);
y2 = -(ur(1)*x2 + ur(3))/ur(2);
plot([x1 x2], [y1 y2]);
title('Left Image with corresponding epipolar line');

%% 
% The point we picked is around the center of the right image, around the
% right white dots of the B letter. Then, we construct the corresponding
% epipolar line on the left image. The error is mainly caused due to the
% manual matching of correspondences that we do earlier on affecting the
% results. This is compounded with noise to cause a noticeable error in the
% final result.


%%
% To calculate the error, we manually pick the correspondence of the right
% image in the left image. We then use that correspondence's x coordinate
% to get its respective y-coordinate on the epipolar line. Then we subtract
% the two y-coordinates to get the error of our Fundamental matrix
% estimate.

% [D3Cords1, D3Cords2] = ginput(1);
% save('D3cords.mat', 'D3Cords1', 'D3Cords2');
load('D3cords.mat');
actualCords2 = -(ur(1)*D3Cords1 + ur(3))/ur(2);

%%
% The offset amount is as follows:
offset = abs(D3Cords2 - actualCords2)
%%
% So our estimate of the fundamental matrix has an error of about 35 pixels
% from the actual correspondence.

%%
% Then, we find the epipolar lines for all eight points we selected in the
% right image. The result image is given below.

figure(1);
title('Eight-Points Epipolar Lines');
for i = 1:8
    newPoint = [rightxCords(i) rightyCords(i) 1];
    ur = FundamentalMatrix*newPoint';
    y1 = -(ur(1)*x1 + ur(3))/ur(2);
    y2 = -(ur(1)*x2 + ur(3))/ur(2);
    hold on;
    plot([x1 x2], [y1 y2]);
end

%%
% We find that the epipolar lines above the middle tilt down while the
% epipolar lines below the middle tilt upward. So, as a result, we expect
% them to intersect to the left outside the image. This intersection is the
% epipole of the camera and provides a good reference for the angle of the
% camera on the image. 

%%
% Observe that the epipolar lines recovered from both the left and right
% images converge to the epipoles to the left. Therefore, we could conclude
% that the two images are taken at the same angle to the scene (to the
% left). However, notice that some of the artifacts (such as the left wheel
% of the robots) are not shown in the left image. Therefore, these two
% images are not taken at the same time.

%% Conclusion
% Using a fundamental matrix, we plot the epipoles and epipolar lines in an
% image pair. The correspondences are picked manually and get that epipolar
% lines to intersect outside the image. The lesson learned is that the
% quality of the epipolar lines is based on the picked correspondences, so
% to find epipoles of many images, the accuracy of the corresponding points
% is the key.

%% Acknowledgement
% The images are provided by Jerod Weinman in his research lab.