%% CSC 262 lab: Feature Descriptors
%
% CSC 262

%% Overview
% We will implement patches to find the keypoints on the given image. We
% will do this by using the Gaussian kernel, finding the patch center’s
% location, and normalizing the gain and bias. We will extract feature
% descriptors of the image using a function at the end.

%% Patch extraction and comparison at different scales
% We start this lab by extracting all the feature keypoints’ locations by
% calling the ‘kpdet’ function from the previous lab. Then, we initialize
% an N-by-64 matrix to collect the detected keypoints. To compare the
% difference of patches on different scales, we downsampled the given image
% by applying a Gaussian kernel with a scale of 5 pixels and then
% downsampled it by a factor of 5 to provide a coarse representation of the
% image. The lab preparation is ready for the next step.

img = im2double(imread('/home/weinman/courses/CSC262/images/kpdet1.tif'));
% The image is obtained from Professor Weinman in Feature Descriptor Lab
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/feature-descriptors.html
featureImg = kpdet(img);
[rows, cols] = find(featureImg);
patch = zeros(length(rows),64);
gaussK = gkern(5^2);
blurImg = conv2(gaussK, gaussK,img,'same');
dsamplefactor = 5;
downImg = blurImg(1:dsamplefactor:end, 1:dsamplefactor:end);

index = 400;
centerPatch = [rows(index),cols(index)];
downCenterPatch = round(centerPatch./dsamplefactor);
upLeftDPatch = [downCenterPatch(1)-3,downCenterPatch(2)+3]; 
botRightDPatch = [downCenterPatch(1)+4,downCenterPatch(2)-4]; 
downSamPatch = downImg(upLeftDPatch(1):1:botRightDPatch(1),botRightDPatch(2):1:upLeftDPatch(2));

upLeftOPatch = [centerPatch(1)-19,centerPatch(2)+19]; 
botRightOPatch = [centerPatch(1)+20,centerPatch(2)-20]; 
originalPatch = img(upLeftOPatch(1):1:botRightOPatch(1),botRightOPatch(2):1:upLeftOPatch(2));

figure;
subplot(1,2,1);
imagesc(downSamPatch,[0 1]); 
colormap(gray);    
axis equal off; 

subplot(1,2,2);
imagesc(originalPatch,[0 1]); 
colormap(gray);    
axis equal off;
sgtitle('Patch comparison between different scale');
% Citation: This sgtitle commaned is obtrained from the matlab forum by the
% Matlab staff: Thiviya Navaneethan
% https://www.mathworks.com/matlabcentral/answers/100459-how-can-i-insert-a-title-over-a-group-of-subplots#:~:text=There%20is%20a%20command%20suptitle,the%20title%20of%20all%20subplots.

%%
% Above, we display a downsampled feature patch from the original image and
% the corresponding feature patch from the original image. The image on the
% left is the downsampled patch while the one on the right is the original
% patch. Utilizing a downsampling factor of 5, the downsampled patch
% represents an 8x8 pixel region, while the original patch represents a
% 40x40 pixel region. 

%%
% We can observe similarities between the two images, specifically in the
% upper right, bottom right, and bottom left portions of the images. In
% these areas, the downsampled patch correctly approximates the dark
% upper-right corner, the dark right edge, and the dark splotch on the left
% side of the original image. The white regions of the original image,
% which run from the bottom left corner to the dark right edge and from the
% upper left corner to the right edge, are also represented within the
% downsampled patch. The muddled gradient from white to the dark splotch
% that makes up the image's central region is also represented in the
% downsampled patch. 

%%
% In more detail, we could divide the image into three categories: edge,
% brightness, and orientation. The downsampled scale patch weakly preserves
% the edge due to the Gaussian kernel's smoothened effect. For example,
% although the transition is observable in both scaled patches on the right
% edge of the white parallelogram, on the left top portion, the edge on the
% left side of the parallelogram is smoothened out in the downsampled patch
% since local contrast around that area is weaker than the top right
% corner.

%%
% For local brightness, a clear black edge lies on the original patch's
% bottom. However, that local contrast is discarded in the downsampled
% patch. So, the downsampled version is not a perfect representation of the
% brightness of the original patch.

%%
% For orientation, since we didn’t implement a matrix to preserve the
% information on orientation, the downsampled patch couldn’t keep all the
% orientation information. For example, on the right side of the original
% patch, there’s an obvious orientation change between the bottom edge of
% the parallelogram and the left side of the parallelogram. But this
% information is hard to gather given the downsampled patch.

%%
% Altogether, we conclude that the downsampled patch makes for an effective
% approximation of the original patch, as it pulls out the defining
% features of the original image while discarding some details. 

%%
% To further improve our patch, we introduce a normalized version of the
% patch's overall bias and gain, preserving the information while not
% changing the value of the image.

%% Patch normalization

pause(1);
figure;
imshow(img);
hold on;
title('Original Image with Patch Center Marked');
PatchCenterPlot = plot(rows(index), cols(index), '+');
PatchCenterPlot.Color = "red";
meanDSam = mean(downSamPatch);
norDSamP = downSamPatch-meanDSam;

%%
% The picture above shows the feature keypoint that we picked randomly
% within the range of features’ number of rows. Its coordinate is marked
% with a red ‘+’.

meanDSam = mean(downSamPatch);
norDSamP = downSamPatch-meanDSam;
stdDSamP = std(downSamPatch);
norSamP = norDSamP ./ stdDSamP;

figure;
imagesc(norSamP);
title('Small Normalized Patch Image');
colormap(gray);
axis equal off;

%%
% Above, we display the normalized downsampled patch from before. To
% normalize the bias and gain of the image, we first subtract the mean of
% all the pixels from the patch. We then divide the resulting
% bias-normalized patch by the downsampled patch’s standard deviation to
% normalize the gain. This results in zero mean and unit variance. 

%%
% The result from the normalized downsampled patch is similar to the
% original, but the brightness values have been adjusted. The contrast
% between various brightnesses is now emphasized, meaning darker regions
% appear darker and lighter regions appear lighter (and gray regions remain
% largely the same). We can also observe a shift in the bottom left region
% of the image, where the darkest point has moved to the right by four
% pixels from the original downsampled image. This is evidence of the
% shifted mean and unit variance from normalization and, overall, seems to
% better represent the dark blotch in this region of the original image.
% The normalization of the downsampled patch should make it more useful for
% feature matching/analysis, as defining features of the patch are more
% defined than previously. 

%%
% Analyzing the image on brightness and edge, the local contrast and
% brightness are better preserved in the normalized version. For example,
% darker values are better represented in the top right corner, bottom
% left, and bottom middle areas. The contrasts between the neighbor pixels
% are more obvious; therefore, the edge is more obvious in the diagonal
% direction.

%%
% However, since we still didn’t implement an orientation matrix, we didn’t
% preserve the information in any orientation. For example, at the same
% location, as we discussed in the previous section, there should be an
% obvious change in the mid-right of the image. However, this image still
% didn’t preserve that information.

features = kpfeat(img,kpdet(img));

%% Conclusion
% We implemented the patches using a Gaussian kernel of a scale of 5
% pixels, a feature detection function, and patch normalization to extract
% feature descriptors in this lab. We find that scale plays a role in
% preserving more keypoints information in a patch and normalizing a patch
% gives a better result. Using a feature descriptor is important because we
% could use the feature descriptor results to match features in an image.

%% Acknowledgement
% The raw image is provided by Professor Weinman
%
% The Matlab markup guide: https://www.mathworks.com/help/matlab/matlab_prog/marking-up-matlab-comments-for-publishing.html
%
% Code is from the lab manual page: https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/feature-descriptors.html#enu:kp-location