%% CSC 262 lab: Pyramids and Wavelets

%% Introduction
% To detect the features of an image at a particular scale, we will make a
% feature detection function by using Gaussian kernel, determinant, and
% trace matrices. We find that the shooting angle and illumination
% influence the feature point detection result. This feature detection is
% important because it gives us the starting point to find and classify
% features in an image.

%% Determinant, Trace, and Feature Strength Images
% For this part of the lab, we'll be using the cameraman.tif image. We
% start by creating a blurred matrix using partial gradients of the image.
% Using this matrix, we create determinant and trace images. 

img = im2double(imread('cameraman.tif'));
gaussK = gkern(1^2);
gaussKdev = gkern(1^2, 1);
singleK = gkern(1.5^2);

Ix = conv2(gaussK, gaussKdev', img,'same');
Iy = conv2(gaussKdev, gaussK', img,'same');

IxSq = Ix .* Ix;
IySq = Iy .* Iy;
IxIy = Ix .* Iy;

IxSqBlr = conv2( IxSq, singleK, 'same');
IySqBlr = conv2( IySq, singleK, 'same');
IxIyBlr = conv2( IxIy, singleK, 'same');

% (10 points) Determinant of feature matrix image (B.2)
% (10 points) Observations of determinant (B.3)
% (10 points) Trace of feature matrix image (B.5)
% (10 points) Observations of trace (B.6)
% (10 points) Feature strength image (B.8)
% (10 points) Observations of feature strength (B.9)

detImg =  (IxSqBlr .* IySqBlr) - (IxIyBlr .* IxIyBlr) ;
figure;
imshow(detImg,[]);
colormap(jet), colorbar;
title('Hot-cool determinant image of cameraman');
%%
% We first analyze determinant image of cameraman. Responses are strongest
% in the corner region of the image. This is because corners have both
% horizontal and vertical gradients. Therefore, when we calculate the
% determinant in an image, Ix^2 + Iy^2 increases the contrast between edges
% and corners. Since ‘-(IxIy)^2’ combines the change in the horizontal and
% vertical direction, if there is more change in only the horizontal
% direction or vertical direction, the magnitude of IxIy is larger in
% regions with more change in both the x and y direction. For example,
% quantitatively, IxIy will become even smaller if both Ix and Iy are
% closer to zero. Ix and Iy are both closer to zero means that at a
% particular point, there is an intersection between a vertical line (where
% Iy is closer to zero) and a horizontal line (where Ix is closer to zero).
% This means there is a sharp orientation shift in between. Therefore, when
% subtracting (IxIy)^2 from Ix^2+Iy^2, the overall value will be larger
% since IxIy is closer to zero in the case of corners, marking the corner
% region of the image.


%% 
% We now display our trace image, as shown belowl.
figure;
traceImg = IxSqBlr + IySqBlr ;
imshow(traceImg,[]);
colormap(jet), colorbar;
title('Hot-cool trace image of cameraman');
%% 
% In the trace image, responses are strongest around the outline of the
% cameraman’s head, shoulders, and arm, and around portions of the camera.
% We can see an especially strong response on the horizontal line formed by
% the cameraman’s shoulders, matching our reasoning above. The light spots
% on the lower portions of the tripod legs are also highly visible where
% they contrast with the black portions. Lastly, the edges between the
% man’s coat and the left tripod leg are also visible, although
% significantly weaker as a result of being diagonal. Other edges, such as
% the background buildings, and the cameraman’s legs and lower torso are
% visible to a lesser degree.  While there weren’t any particularly strong
% vertical edges, this is unsurprising given the lack of strong vertical
% gradients in the original cameraman image.

%%
% Using these images, we create our feature strength image by dividing our
% determinant image by our trace image.
figure;
fStrengthImg = detImg ./ traceImg ;
imshow(fStrengthImg,[]);
colormap(jet), colorbar;
title('Hot-cool feature strength image of cameraman');
% impixelinfo;
%% 
% Responses that had values significantly above zero in the determinant
% image and the trace image tended to be strong. Since the determinant
% image is divided by the trace image, any visually noticeable response in
% the determinant image divided by an extremely small (weak-response) value
% in the trace image would be strong. However, since the trace image
% contained responses that were at least as strong or stronger than the
% determinant image in virtually every location, this never happened.
% Instead, the strongest responses we saw were in locations that were
% relatively strong in both of the constituent images, most notably the
% cameraman’s left elbow and the portion of the camera apparatus directly
% above it. Weak values in the determinant also became significantly
% stronger in the feature strength. This can be seen with the right tripod
% leg, which is barely visible in the determinant, but fairly visible in
% both the trace and feature strength image. Extremely weak responses in
% the determinant image would always be similarly weak in the feature
% strength image, regardless of their strength in the trace image. This can
% be seen with the cameraman’s back and shoulders, which were highly
% visible in the trace image, but had extremely weak responses in both the
% determinant and feature strength image.
% By looking at the local maxima and applying a threshold to the feature
% strength image, we get a logical feature detection image. 

%% Generalization and Detection Comparison between Two Images 
% Generalize this proccess into a function, kpdet, and apply it to 2 new
% images, which we'll call kpdet1 and kpdet2. These images are of the same
% general location, taken from slightly different camera positions and
% angles. After applying our feature detecting function to the two images,
% we display the original images with the interest points plotted on top of
% them.
%% 

threshold = 0.001;
thresholdedStrengthImg = fStrengthImg > threshold;
maxStrength = maxima(fStrengthImg);
% figure;
% imshow(maxStrength);
thresholdMax = (maxStrength + thresholdedStrengthImg)>= 2;

% (10 points) Feature detection results (E.5)
% (10 points) Feature detection observations (E.6)

kpdet1 = im2double(imread('/home/weinman/courses/CSC262/images/kpdet1.tif'));
kpdet2 = im2double(imread('/home/weinman/courses/CSC262/images/kpdet2.tif'));


kp1 = kpdet(kpdet1);
kp2 = kpdet(kpdet2);

[findKp1X, findKp1Y] = find(kp1);
[findKp2X, findKp2Y] = find(kp2);

figure;
imshow(kpdet1);
hold on;
plot(findKp1Y, findKp1X, "+");
title('Feature Locations on Kpdet1 with threshold of 0.001');
pause(1);

figure;
imshow(kpdet2);
hold on;
plot(findKp2Y, findKp2X, "+");
title('Feature Locations on Kpdet2 with threshold of 0.001');
%% Kpdet Comparison Observations
% By the feature detection algorithm, we expect features detected to be in
% the corners of artifacts where there are obvious local contrasts within a
% small range since our kernel size is relatively small. Also, since
% Kpdet2’s filming angle is higher than Kpdet1’s and both images are
% filming the same artifacts, we expect Kpdet2 will detect more feature
% points than Kpdet1 since there will be more obvious corners in Kpdet2 as
% a result of the higher camera shooting angle.

%%
% Based on the experimental result, overall, the feature locations detected
% in both Kpdet1 and Kpdet2 cover most of the corners within blocks and
% between tree leaves that have obvious contrasts on a relatively small
% scale. However, both images fail to detect corners that are compressed
% due to low camera angle, and corners that overlap with the bright
% reflection from the pool.

%% 
% We now analyze and compare the feature detection results. The bottom
% section covers all the blocks stacked together and some of the grass
% beside the pool. With a lower shooting angle, differences in some corners
% are obvious. For example, in the frontmost pool, Kpdet1 detects features
% at the corner while Kpdet2 does not. This is because as the shooting
% angle decreases, more shadow is captured next to the corner while
% preserving the bright portion on the top of the pool block. The same
% principle applies to the stacked blocks further away in the second pool,
% where we can see a similar, but less pronounced outcome.

%% 
% Aside from the effect of shooting angle, another difference in the bottom
% part is the amount of illumination. The grass portion in Kpdet1 is
% brighter than the same portion in Kpdet2. As a result of this, more
% feature points are captured in Kpdet1 than in Kpdet2. 

%%
% Some features are ignored in the Kpdet1 but preserved by Kpdet2 because
% the edges between the dark and bright are more inclined. For example, on
% the inner edge near the ‘back’ of the closest pool, there are more
% feature points in Kpdet2 compared to Kpdet1. This is because the kernel
% detects feature points better when they are viewed from a steeper angle,
% and there will be less jagging created locally that distribute the
% contrasts on the edge.

%%
% Another interesting observation is that both Kpdet1 and Kpdet2 detect the
% left edge of the pool while ignoring the right edge of the pool blocks.

%%
% A similar trend happens in the top partition of the stacked blocks.  On
% the top section of the image, a similar trend applies: with higher
% brightness, more feature points are detected. This effect is very obvious
% on the top right side of the tree. However, another feature point
% difference lies in the left top corner of the furthest dark window on the
% first floor of the building. The left top corner is detected by Kpdet1
% while being ignored by Kpdet2. As we zoom closer, Kpdet1’s corner‘s
% contrasts are curved while Kpdet2’s corner is rectangular. This is
% counterintuitive because we might think rectangle transition contrasts
% are more obvious than the curved transition contrast. This could be
% explained as when we use the Gaussian kernel to smooth the image, we
% preserve the curved transition, while smoothing the rectangle region,
% causing the contrasts to disappear.



%% Conclusion
% Feature detection is a valuable tool, but has significant drawbacks.
% Image matching can highlight visually relevant artifacts for viewers, or
% be used as input for more complex algorithms. Determining a good
% threshold for feature detection requires careful observation. Trial and
% error can be necessary to optimize the displayed features according to
% the target image and the artifacts that the user wants to detect. The
% algorithm can also fail to detect certain features due to low camera
% angle or reflectance, such as the compressed corners we saw in our latter
% two images. 

%% Acknowledgement
% The raw image is provided by MatLab. The second image is provided by
% Professor Weinman.
%
% The Matlab markup guide: https://www.mathworks.com/help/matlab/matlab_prog/marking-up-matlab-comments-for-publishing.html
%
% Code is from the lab manual page: https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/feature-detection.html