%% CSC 262 lab: Feature Matching
%
% CSC 262

%% Overview
% We will use feature detection and descriptor functions in this lab to
% write a matching algorithm. We will stitch two images based on the
% matched results at the end. This lab is important because it is the last
% step in the feature process, allowing us to implement the
% feature-matching function on real images.

%% Feature comparison and matching
% This lab aims to align two images using feature detection and feature
% descriptors. The first step is to detect the feature and find the
% descriptors. However, possibly detected features closer to each other are
% confusing since we couldn’t pick which one corresponds to the reference
% image's feature. Therefore, we need to calculate and sort the Euclidean
% distance between features. This could determine whether a distance is
% valid, depending on the threshold we set.

img1 = im2double(imread('/home/weinman/courses/CSC262/images/kpmatch1.png'));
img2 = im2double(imread('/home/weinman/courses/CSC262/images/kpmatch2.png'));
% Citation: The image is obtained from Professor Weinman's Feature Matching Lab
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/feature-matching.html#enu:align-trans-obs

kpLocation1 = kpdet(img1);
kpLocation2 = kpdet(img2);

[rows1,cols1] = find(kpLocation1);
[rows2,cols2] = find(kpLocation2);

kpDescriptor1 = kpfeat(img1,kpLocation1);
kpDescriptor2 = kpfeat(img2,kpLocation2);

[featRows1,featCols1] = find(kpDescriptor1);
[featRows2,featCols2] = find(kpDescriptor2);

% reference img = img1
feat1Index = 100;
feat1 = kpDescriptor1(feat1Index,:);
isValidFeat = isnan(feat1);
diff = kpDescriptor2 - feat1;

eucd = sqrt(sum(diff.^2, 2)); % 2 implies summing the rows
% This way of calculating euclidean is obtained from the MatLab Forum: reference: https://www.mathworks.com/matlabcentral/answers/2849-euclidean-distance-of-two-vectors

[eucdSortValue, eucdSortIndices] = sort(eucd);
% B7
figure;
bar(eucdSortValue(1:10));
title('Closest 10 Features');
xlabel('Index');
ylabel('Euclidean Distance');

%%
% The histogram above is an example to show how the feature is chosen.
% First, we pick a feature descriptor within the range of the reference
% image’s width whose index is 100, using the feature descriptor function
% with a descriptor size of image width*64 and a feature detection function
% with a Gaussian kernel of 5 pixels. Then, we sort the first ten closest
% features to the feature in the original picture. The first ten closest
% matches are within 6 pixels away from the reference. So, these features
% are clustered rather than distributed. 

%%
% Notice that the first feature has a distance of around 1.3 pixels, while
% the second closest feature has a distance of 2 pixels. The second closest
% feature almost doubles the distance of the closest feature. Therefore, we
% treat the closest feature point as a significant feature. Also, the
% closest match feature has a distance of around 1 pixel. So, the quality
% of the match is not bad.

%%
% We also calculate the estimated translation from our reference feature's
% first image to the location of the best matching feature in the other
% image by subtracting the row and column of the reference feature from the
% matching feature. As a result, we find a row column translation of 149
% and a row translation of -1.

pause(1);

feat2Index = eucdSortIndices(1);
feat1row = rows1(feat1Index);
feat1col = cols1(feat1Index);

feat2row = rows2(feat2Index);
feat2col = cols2(feat2Index);

tr = (feat2row - feat1row);
tc = (feat2col - feat1col);

eucdSortIndices(1);

concatImg = cat(2,img1,img2);
% Citation:  This 'cat' command is obtained from the MatLab Forum: https://www.mathworks.com/matlabcentral/answers/129488-how-to-join-two-image

figure;
imshow(concatImg);
title('Matched Feature Image');
imgWidth = size(img1,2);
line([feat1col,(feat1col+tc+imgWidth)],[feat1row,(feat1row+tr)],'Color','red');
%%
% The image above shows the feature whose index is 100. The matched feature
% points are calculated after being translated over the reference image’s
% width. They are located on the top left corner of the waterfall on the
% right.

transDists = zeros(length(rows1),2);
count = 0;

concatImg = cat(2,img1,img2);
% Citation: This 'cat' command is obtained from the MatLab Forum: https://www.mathworks.com/matlabcentral/answers/129488-how-to-join-two-image

figure;
imshow(concatImg);
hold on;
title('More Features Matched Image');

for i=1:length(rows1)
% reference img = img1
feat1Index = i;
feat1 = kpDescriptor1(feat1Index,:);
isAnyNaN = isnan(feat1);
if any(isAnyNaN(:)==1)
    % This 'any' is obtained from the MatLab Forum: https://www.mathworks.com/matlabcentral/answers/128553-check-for-1-in-a-array
    transDists(i,:) = NaN;
    continue;
end
diff = kpDescriptor2 - feat1;

eucd = sqrt(sum(diff.^2, 2)); % 2 implies summing the rows
% reference: This way of calculating euclidiean distance is obtained from the MatLab Forum: https://www.mathworks.com/matlabcentral/answers/2849-euclidean-distance-of-two-vectors

[eucdSortValue, eucdSortIndices] = sort(eucd);

nearestNeighborRat = eucdSortValue(1)/eucdSortValue(2);
if nearestNeighborRat > 0.5
    transDists(i,:) = NaN;
    continue;
end
feat2Index = eucdSortIndices(1);
feat1row = rows1(feat1Index);
feat1col = cols1(feat1Index);

feat2row = rows2(feat2Index);
feat2col = cols2(feat2Index);

tr = (feat2row - feat1row);
tc = (feat2col - feat1col);

transDists(i,1) = tr;
transDists(i,2) = tc; 

line([feat1col,(feat1col+tc+imgWidth)],[feat1row,(feat1row+tr)],'Color','red');

count = count + 1; % count the number of non-NaN value in the translation matrix
end

hold off;
%%
% Then, we match all the significant features grabbed from the reference
% image with a threshold of 0.5. In total, twenty-two features are
% clustered in the bottom left-bottom corner of the image. These features
% are clustered in the foreground with bright water and dark stones shaped
% close to rectangles. This area has relatively rapid changes in both
% horizontal and vertical directions, making it easier to be detected by
% the kpdet function. 

%% 
% Another obvious reason is the size of the descriptor matrix. The
% descriptor matrix has a size of N*64. Therefore, if a feature is close to
% the edge of the image, it will be ignored since all the column values of
% that descriptor will be thrown away. However, this also ensures that when
% we stitch two images together, they wouldn’t simply stitch the image edge
% to edge due to a sudden change at the edge of an image. Another advantage
% the clustered pattern has is that it could make the stitching more
% robust. For example, suppose two images are stitched together based on
% distributed features. In that case, if there is a change in orientation,
% scale, or affine, as the features get distributed away from the reference
% features, there will be more unnatural deformation over those areas.

%% Image alignment using the matched features
% The next step is to use the matched feature to stitch the image
% carefully. This allows us to have a distinctive evaluation of the
% feature-matching process. By taking the mean of all the translation
% distances between all significant feature estimates, we find a mean
% column translation of 141 and a mean row translation of 0. The row
% translations have a standard deviation of 1.4771, and the column
% translations have a standard deviation of 1.7037. This means that the
% translation between the first and second image is nearly entirely in the
% x-direction (0 was a rounded mean for the row translations). The fact
% that the standard deviation is between one and two pixels for both rows
% and columns means that the majority of feature translation (68%) is
% within one to two pixels of the mean. This means that the application of
% the mean translation for image stitching should produce a high-quality
% result (because most translations are within 1-2 pixels of the mean).

% Q: Why we don't care if the number of features in img1 is more than img2?

meanTranR = mean(transDists(:,1),'omitnan');
meanTranC = mean(transDists(:,2),'omitnan');
stdR = std(transDists(:,1),'omitnan');
stdC = std(transDists(:,2),'omitnan');

figure;
stitchedImg = stitch(img2, img1, [round(meanTranR) round(meanTranC)]);
imshow(stitchedImg);
title('Stitched Image');

%%
% Above, we display the two original images, stitched according to the mean
% row and column translations. Again, we observe satisfactory image
% stitching. It works well in the water foreground of the right stitching
% edge, where the textures of the water seem to line up, and the rocks in
% the water line up almost perfectly. It also works well along the
% waterfall of the left stitching edge, where the stitching is almost
% indiscernible, and the cliff edges line up nearly perfectly. 

%%
% However, we can also observe the effect of having zero mean row
% translation, where the layered images almost echo each other instead of
% lining up with one another. This can be observed prominently at the top
% of the right stitching edge, where the two layers where the trees and the
% top of the waterfall line up are clearly visible. This echoing effect is
% evidence of weak mean row translation and can be seen all along the top
% of the cliff edge in the stitching region. However, this effect is hardly
% visible in the foreground and the bushes at the base of the cliff; the
% majority of the image stitching has performed well.

%%
% This inconsistency could also be due to a change in camera angle; a
% camera angle angled down/up between the two images would skew the mean
% column translation, making some regions work with zero translation and
% others struggle. Inconsistency from the mean column translation is less
% apparent, but it can be observed in the tallest tree in front of the
% right waterfall along the right stitching edge, where there is a
% noticeable echo between the image layering.

%% Conclusion
% In this lab, we used the feature detection function and the feature
% descriptor function to match features between similar pictures according
% to their Euclidean distances. A threshold of 0.5 was used to determine
% whether feature matching was significant. This procedure is useful
% because we finished the last step of the feature process by examining
% translation distances between significant matching features, and we were
% able to analyze and align two images by utilizing a provided image
% stitching function.

%% Acknowledgement
% The raw image is provided by MatLab.
%
% The Matlab markup guide: https://www.mathworks.com/help/matlab/matlab_prog/marking-up-matlab-comments-for-publishing.html
%
% Code is from the lab manual page: https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/feature-matching.html