function detectionImg = kpdet(img)
%UNTITLED2 ADD DOCUMENTATION LATER
%   Detailed explanation goes here
    funcGaussK = gkern(1^2);
    funcGaussKdev = gkern(1^2, 1);
    funcSingleK = gkern(1.5^2);

    funcIx = conv2(funcGaussK, funcGaussKdev', img,'same');
    funcIy = conv2(funcGaussKdev, funcGaussK', img,'same');

    funcIxSq = funcIx .* funcIx;
    funcIySq = funcIy .* funcIy;
    funcIxIy = funcIx .* funcIy;

    funcIxSqBlr = conv2( funcIxSq, funcSingleK, 'same');
    funcIySqBlr = conv2( funcIySq, funcSingleK, 'same');
    funcIxIyBlr = conv2( funcIxIy, funcSingleK, 'same');
    
    funcDetImg =  (funcIxSqBlr .* funcIySqBlr) - (funcIxIyBlr .* funcIxIyBlr) ;
    funcTraceImg = funcIxSqBlr + funcIySqBlr ;
    funcFStrengthImg = funcDetImg ./ funcTraceImg ;
    %figure;
    %imshow(funcFStrengthImg,[]);
    %title('test funcFStrengthImg ');
%     colormap(jet), colorbar();
    funcThreshold = 0.001;
    funcThresholdedStrengthImg = funcFStrengthImg > funcThreshold;
    
    funcMaxStrength = maxima(funcFStrengthImg);
   
    detectionImg = (funcMaxStrength + funcThresholdedStrengthImg)>=2;
end

