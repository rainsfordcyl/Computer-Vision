function features = kpfeat(funcImg,keypoints)
% KPFEAT Finds the feature descriptors and their coordinates in an image.
%
% It finds the feautres descriptors from a matrix 'funcImg' and its
% corresponding feature points given by the 'kpdet' function. It returns a
% N*64 matrix of feature descriptors and a corresponding N*2 matrix of the
% features'row and column coorinates.
%
% CSC-262 Lab: Feature Matching

funcImg = im2double(funcImg);

% Locate the rows and columns where feature keypoints were detected in the
% image.

[funcRows, funcCols] = find(keypoints);
features = zeros(length(funcRows),64);

% Use Gaussian kernel with a scale of 5 pixels to blur the image.

funcGaussK = gkern(5^2);
funcBlurImg = conv2(funcGaussK, funcGaussK,funcImg,'same');
funcDsamplefactor = 5;

% Downsample the image by a factor of 5

funcDownImg = funcBlurImg(1:funcDsamplefactor:end, 1:funcDsamplefactor:end);

[dCols, dRows] = size(funcDownImg);
% Extract and normalize the patch over all the keypoints found above

for i = 1:length(funcRows)
    % Get the upperleft and bottom right coordinates of a patch from the
    % center
    centerPatch = [funcRows(i),funcCols(i)];
    dCntrP = round(centerPatch./funcDsamplefactor);
    uLDPatch = [dCntrP(1)-3,dCntrP(2)+3]; 
    bRDPatch = [dCntrP(1)+4,dCntrP(2)-4]; 
    
    % Set the entries in the ith row of the feature matrix to NaN if the
    % patch falls out of bound.
    if (uLDPatch(1) <= 0) || (uLDPatch(2) <= 0)
        features(i,:) = NaN;
        continue;
    
    elseif (bRDPatch(1) <= 0) || (bRDPatch(2)<= 0)
        features(i,:) = NaN;
        continue;
    elseif (uLDPatch(1) > dCols) || (uLDPatch(2)> dRows)
        features(i,:) = NaN;
        continue;
    elseif (bRDPatch(1) > dCols) || (bRDPatch(2) > dRows)
        features(i,:) = NaN;
        continue;
    else
        % If the patch didn't fall out of bound, then normalize the patch
        dSamPatch = funcDownImg(uLDPatch(1):1:bRDPatch(1),bRDPatch(2):1:uLDPatch(2));
    
        meanDSam = mean(dSamPatch);
        norDSamP = dSamPatch-meanDSam;
        stdDSamP = std(dSamPatch);
        norSamP = norDSamP ./ stdDSamP;
    
        features(i,:) = norSamP(:);
    end
    
end
end

