%% Lab: Fourier Transform 1
% CSC-262
% 
%% Overview
% In this lab, we will be displaying and analyzing basic sinusoidal 
% functions and their fourier transforms, paying special attention to the
% effects of changing frequency, phase, and orientation. We saw that
% changing frequency alters the displacement of peak values in the
% corresponding fourier transform. We also saw that a change in phase has
% no effect on the magnitude of fourier transform values, but does indeed
% change the phase component of fourier transform values. Finally, a change
% in orientation does not affect peak value displacement in the fourier
% transform. It simply rotates these values the same number of radians as
% the original function.

%% Analysis of Frequency of Basis Function Transforms
% We begin by displaying a simple cosine function below.

[xx,yy] = meshgrid(0:255,0:255);
cosFunc1 = cos(2 * pi * (4/256) .* xx);
figure;
imshow(cosFunc1,[]);
title('Representation of the function z = cos(2 pi 4/256 x)');
%%
% Upon observation, we see that this periodic function shows four cycles.
% Therefore, as there are 256 pixels along the x axis, the frequency of
% this function is 1/64 pixels per cycle.

%%
% We will now find the Fourier transform of the above image. For
% visualization purposes, we see the logarithm of the magnitude of the
% fourier transformation below.
fftCosFunc1 = fftshift(fft2(cosFunc1));
magFftCosFunc1 = abs(fftCosFunc1);
logMagFftCosFunc1 = log(magFftCosFunc1);
figure;
imshow(logMagFftCosFunc1 + 1, []);
title('Log of magnitude of FFT of first cosine function');
%%
% Notice that the only visible pixels occur at pixel locations (125,129) and
% (133, 129). Given a center of (129,129), we see that these pixels are
% four pixels away along the x axis from the center. This displacement
% corresponds with the number of cycles we identified in the original
% image. This tells us there are two frequencies present. The scale and
% orientation of the first is 4 and to the right. The scale and orientation
% of the second is also 4 and to the left. This can be
% accounted for by conjugate symmetry.

%%
% We now create another cosine function with a different form for analysis.
% This image is shown below.

cosFunc2 = cos(2 * pi * (8/256) .* xx);
figure;
imshow(cosFunc2,[]);
title('Representation of the function z = cos(2 pi 8/256 x)');
%%
% We observe 8 cycles on this image which, given a 256x256 image, gives us
% a frequency of 1/32 pixels per cycle.
%%
% Taking the fourier transform of this function and displaying it in the
% same way as with the first cosine function gives us the below image.
logMagFftCosFunc2 = log(abs(fftshift(fft2(cosFunc2))));
figure;
imshow(logMagFftCosFunc2 + 1, []);
title('Log of magnitude of FFT of second cosine function');
%%
% We see that this time, the peaks are 8 pixels away from the center of the
% image along the x axis in both directions. This tells us that there are
% again 2 frequencies present. The first is at a scale of 8 and to the
% right and the second is at a scale of 8 and to the left. This can be
% again accounted for by conjugate symmetry. This image shows twice as many
% cycles as the first image and has peaks in its Fourier transform twice as
% far away from the center as the first image along the x axis. Although
% their peaks appeared in different locations, both images had only two
% total peaks in the same direction.

%% Analysis of Phase of Basis Function Transforms
% Let's now create another sinusoidal function using sine instead of
% cosine. An image representation of this function is displayed below.
figure;
sinFunc = sin(2 * pi * (4/256) .* xx);
imshow(sinFunc,[]);
title('Representation of the function z = sin(2 pi (4/256) x)');
%%
% This representation shows 4 peaks which corresponds to a frequency of
% 1/64 pixels per cycle just like with our first function. Before we take
% the fourier transform of this image, let us predict where the peaks will
% be located. We predict the peaks to be located in the same location as
% with the first cosine function because both of these functions have the
% same number of cycles and their waves are oriented in the same direction.
%%
% Taking the fourier transform of this image and displaying it the same as
% above gives us the following image.
logMagFftSinFunc = log(abs(fftshift(fft2(sinFunc))));
figure;
imshow(logMagFftSinFunc + 1, []);
title('Log of magnitude of FFT of the sine function');
%%
% We see the peaks to be in the same location as the first function, at a
% displacement of 4 pixels from the center of the image along the x axis in
% both directions. The magnitudes are the same between this sine function
% and the first function which was a cosine function. The peak locations
% occur in the same locations as the cosine function because they both have
% the same number of cycles and both waves follow the x axis. (frequency and
% orientation are the same)
%%
% Let's now show the phase of pixels on the 129th (middle) row between
% columns 124 and 134 in both the first cosine function and the sine 
% function. This will capture the peak pixels and their neighbors.
figure;
fftSinFunc = fft2(sinFunc);
fftCosFunc1Phase = fftshift(angle(fftCosFunc1));
fftSinFuncPhase = fftshift(angle(fftSinFunc));
plot(124:134, fftSinFuncPhase(129, 124:134), 'red');
hold on;
plot(124:134, fftCosFunc1Phase(129, 124:134), 'blue');
legend('Sine Function', 'Cosine Function');
title('Phase Analysis of Sine and Cosine Functions');
xlabel('Pixel Row');
ylabel('Phase of Pixel');
%%
% We see that the phase for the cosine function remains constant at 0 while
% the sine function oscillates roughly between pi/2 and -pi/2. This is
% because phase is responsible for ofsetting the various sinusoids used by
% the fourier transform. The cosine function requires no offset, so the
% phase is always 0. On ther other hand, the sine function does require an
% offset, so it's phase value is nonzero. The oscillation between pi/2 and
% -pi/2 can be accounted for by conjugate symmetry.

%% Analysis of Orientation of Basis Transforms
% Finally, we will take the second cosine function from above and rotate it
% 45 degrees counterclockwise. This image is displayed below.
xrot = (xx * cos(-pi/4)) + (yy * sin(-pi/4));
rotCosFunc2 = cos(2 * pi * (8/256) .* xrot);
figure;
imshow(rotCosFunc2, []);
title('45 degree counterclockwise rotation of second cosine function');
%%
% As we have done for the functions above, we will take the fourier
% transform of the image and display it using the magnitude of the fourier
% transform at each pixel. This time, we do not take the logarithm of the
% values.
magFftRotCosFunc2 = abs(fftshift(fft2(rotCosFunc2)));
figure;
imshow(magFftRotCosFunc2, []);
title('Magnitude of FFT of the Rotated Cosine Function');
%%
% Notice that again, we have two peaks. This time, the peaks are rotated
% pi/4 radians just like the original image. Each of these peaks lie 6 
% pixels away along the x axis and 6 pixels away along the y axis. Using 
% these displacements, we can calculate through right triangles that the 
% absolute distance from the center of the image is roughly 8 pixels which
% corresponds to the peak displacement seen in the original cosine
% function. Therefore, the peaks were simply rotated and not any further
% away from the center of the image than the unrotated cosine function.

%% Conclusion
% Our study shows that as frequency increases in a sinusoidal function,
% displacement of peaks in the corresponding fourier transform increases
% linearly. Further, we showed that a change in phase of a sinusoidal
% function, specifically a shift of pi/4 leads to no chang in the
% displacement of peaks in the corresponding magnitude of the fourier 
% transform, but does show a change in phase in the corresponding fourier
% transform. Finally, we show that an orientation shift, specifically one
% of pi/4 radians in a sinusoidal function results in roughly no change in
% absolute displacement from the center to the peaks in the fourier
% transform, but does result in a pi/4 radian rotation in the orientation
% of these peaks in the fourier transform.

%% Acknowledgments
% Some of the function calls were copied from the Fourier Transform lab on
% Professor Weinman's CSC-262 website. MatLab documenation was also
% consulted on several occasions.