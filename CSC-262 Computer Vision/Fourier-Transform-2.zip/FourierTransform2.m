%% Lab: Fourier Transform 2
% CSC-262
% 
%% Overview
% In this lab, we will be creating and analyzing Fourier Transform blurring
% techniques using three filters: The Gaussian filter, The Laplacian of the
% Gaussian filter, and a Simple Box filter. We saw that the Gaussian filter
% and Laplacian of the Gaussian filter work to preserve different
% frequencies of waves and the box filter preserves waves of specific
% orientations better than others and is therefore not a very effective
% blurring filter.
%% Fourier Transform of a Gaussian Matrix
% We begin by plotting a two dimentional gaussian matrix and the magnitude
% of it's corresponding fourier transform.
[xx,yy] = meshgrid(linspace(-20,20,256), linspace(-20,20,256));
gaussMatrix = exp(-(xx.^2 + yy.^2)/2);
gaussMatrix = gaussMatrix.* (1/sum(gaussMatrix(:)));
gaussMatrixFft = fft2(gaussMatrix);
MagGaussMatrixFft = abs(fftshift(gaussMatrixFft));
subplot(2,1,1);
mesh(xx,yy, gaussMatrix);
title('Gaussian Matrix');
xlabel('Matrix Row');
ylabel('Matrix Column');
zlabel('Element Value');
subplot(2,1,2);
mesh(xx,yy,MagGaussMatrixFft);
title('Magnitude of Gaussian Matrix Fourier Transform');
xlabel('u');
ylabel('v');
zlabel('Magnitude Value');
%%
% Upon inspection, we see that the shape of both plots is very similar. The
% difference lies in the scale of the z axis. The largest magnitude in the
% fourier transform of the gaussian matrix is 1 because, by definition of
% the fourier transform, when u and v are 0, the value is merely the
% summation of each element value.

%% Gaussian Filter Blurring
% In the rest of the lab, we will be analyzing and manipulating the 
% following image.
img = im2double(imread('/home/weinman/courses/CSC262/images/tree.png'));
figure;
imshow(img);
title('Original Image');
%%
% We now take the Fourier transform of the image and display the log
% shifted version of the magnitude spectrum. We abbreviate Fourier
% transform as Fft for the rest of the lab.
fftImg = fft2(img);
logMagFftImg = log(abs(img));
logMagShiftFftImg = log(abs(fftshift(fftImg)));
figure;
imshow(logMagShiftFftImg, []);
title('Magnitude of Image Fft');
%%
% We also display the log shifted version of the magnitude spectrum of our
% Gaussian kernel Fourier Transform.
logMagGaussMatrixFft = log(MagGaussMatrixFft);
logMagShiftGaussMatrixFft = log(abs(fftshift(gaussMatrixFft)));
figure;
imshow(logMagShiftGaussMatrixFft, []);
title('Magnitude of Gaussian Kernel Fft');
%%
% Multiplying each element of the above image with the fourier transform
% of the Gaussian kernel we produced earlier gives us the following image.
gaussImgProduct = gaussMatrixFft .* fftImg;
logMagShiftGaussImgProduct = log(abs(fftshift(gaussImgProduct)));
figure;
imshow(logMagShiftGaussImgProduct,[]);
title('Product of Gaussian and Image Fft');
%%
% We can see that taking the product of the Fft of our image with
% our the Fft of our Gaussian kernel works to preserve areas of low 
% frequency and remove areas of high frequency as the center of the image 
% remains bright while the peripheral areas become noticibly darker.

%%
% Next, we take the inverse Fft of our product image and
% observe it.
inverseGaussImgProduct = ifft2(gaussImgProduct);
realShiftInverseGaussImgProduct = real(ifftshift(inverseGaussImgProduct));
subplot(1,2,1);
imshow(img);
title('Original Image');
subplot(1,2,2);
imshow(realShiftInverseGaussImgProduct,[]);
title('Inverse Fft of Product Image');
%%
% We observe a general blurring effect on the original image similar to
% that of convolution. Further, we notice no issues associated with the
% border of the image like we would see in typical convolution.
% Specifically, there is no black border around the ends of the image.
% Because of the convolution theorem, we know that this image is the same
% as simply convolving our original image with the regular gaussian kernel.

%% Laplacian of the Gaussian Filter Blurring
% Let's explore the use of a different filter, namely the Laplacian of the
% Gaussian filter.
laplacian = -(1-(xx.^2 + yy.^2)/2) .* gaussMatrix;
subplot(1,2,1);
imshow(laplacian, []);
title('Laplacian of the Gaussian Kernel');
subplot(1,2,2);
mesh(xx,yy,laplacian);
title('Plot of Laplacian of the Gaussian Kernel');
xlabel('Matrix Row');
ylabel('Matrix Column');
zlabel('Element Value');
%%
% From inspection of this kernel, we expect areas of very low frequency and
% very high frequency to not be preserved while areas of mid frequency are
% preserved.
fftLaplacian = fft2(laplacian);
figure;
imshow(log(abs(fftshift(fftLaplacian))), []);
title('Magnitude of Laplacian Kernel Fft')
%%
% In observing this Fft, we predict it to detect areas of mid
% frequency and ignore all other frequencies. As it is dark in the center
% and periphery and bright in a ring around the center.
laplacianImgFftProduct = fftLaplacian .* fftImg;
inverseLapImgProd = ifft2(laplacianImgFftProduct);
realShiftInverseLapImgProd = real(ifftshift(inverseLapImgProd));
figure;
subplot(1,2,1);
imshow(img);
title('Original Image');
subplot(1,2,2);
imshow(realShiftInverseLapImgProd,[]);
title('Product of Laplacian and Image Fft');
%%
% We can see that responses are strongest among areas of low frequency such
% as the glass panes and the ornament in the bottom right of the image.
% Areas of high frequency show the weakest responses such as the lights on
% the tree. This does not match our predictions because we thought both low
% and high frequencies would not be preserved.

%% Box Filter Blurring
% Finally, we will be creating and analyzing a simple box filter. We create
% a 10x10 normalized box filter in the top left corner of a larger kernel 
% of all zeros. The log shifted magnitude of the Fourier transform of this
% kernel is displayed below. Warmer colors indicate higher magnitudes.
box = zeros(256,256);
box(1:10, 1:10) = .01;
fftBox = fft2(box);
logMagShiftFftBox = log(abs(fftshift(fftBox)));
figure;
imshow(logMagShiftFftBox, []);
colormap(jet);
title('Magnitude of Box Filter Fft');
%%
% We see that the result is isotropic. We should avoid smoothing with this
% box filter before downsampling because we see that detection occurs along
% squares and not a smooth circle as we saw with the gaussian kernel. 
% Specifically, horizontal and vertical orientations will be represented
% stronger than diagonal ones. This will result in square shaped artificats 
% in the smoothing process. Using this filter on the original image gives 
% us the following result.
figure;
imshow(ifft2(fftBox .* fftImg), []);
title('Blurred Image Using Box Filter');
%%
% Notice that indeed there are square artifacts in the smoothed image in
% areas of high frequency such as in the lights.

%% Conclusion
% We found that the Gaussian
% filter works to preserve areas of high frequency and remove areas of the 
% image with low frequency in the fourier transform of the image. 
% Conversely, the Laplacian of the Gaussian Filter removes areas of high 
% frequency and  preserves areas of low frequency. Finally, we find that
% the box filter better preserves waves oriented horizontally or vertically
% than waves oriented diagonally therefore creating boxy artifacts in the
% resulting blurred image. For this reason, box filters should be avoided
% when attempting to blur an image.
%% Acknowledgments
% Some of the function calls were copied from the Fourier Transform 2 lab 
% on Professor Weinman's CSC-262 website. MatLab documenation was also
% consulted on several occasions.