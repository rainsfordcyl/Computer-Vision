%% CSC 262 lab: Image Filtering
%
% CSC 262

%% Introduction
% In today’s lab, we will compare the two separable kernels, Box-Filtering 
% and Gaussian-Filtering, by applying them to the same image and then 
% compare the processed results. We will also explore the reason why the 
% two separable 1-D Gaussian smoothing kernels are faster than the 2-D 
% Gaussian smoothing kernel by experiment and calculate the theoretical 
% result. In addition, we also use filtering to detect instances of 
% “features” in an image. We will also use the sample and correlation 
% method to detect all the letter ‘t’s in a given text image. Lastly, 
% we will use unsharp masking to sharpen an image.
%% 
% In general, we find that Box-Filtering preserves the direction of the 
% hair but creates an odd  shaded area next to certain regions like the 
% pupils and the nose. The Gaussian filter preserves the shape of the eyes 
% but blurs and mixes the direction of the hair. Separable 1-D Gaussian 
% smoothing kernels should process the same image 16.5 times faster than 
% the 2-D Gaussian smoothing kernel for the 33x33 kernel area. Theoretically,
% it is generally K/2 times faster using the separable kernels. In reality,
% the separable kernels only outperform the 2-D Gaussian kernel by roughly
% a factor of 10 for our kernel size. Moving on to correlation, the dot 
% product filtering showed spots of heightened correlation between regions
% of the image and the template image of the “t”. Not until we used a 
% threshold of 10 were all instances of the letter ‘t’ identified in the 
% main section of the text with no false positives. Finally, we achieve 
% unsharp masking on a color image by blurring the three RGB channels of
% the image separately, combining them together, and using the unsharp 
% masking formula with a gamma value of 1.2. The resulting image has an 
% appealing sharpened contrast, but the gamma value of 1.2 sharpened it 
% more than would be ideal.


%% Process
% We first load the picture from Matlab.

%load the image from Matlab
load mandrill
%convert the image from indexed color image to grayscale image
img = im2double(ind2gray(X,map));
clear map;
figure;
imshow(img);
title('Original Image');
%a1 - making boxcar
boxcar = .1*ones(1,10, 'double');
%a2 - box kernel
boxKernel = boxcar'*boxcar;

%a3 - yes it is normalized

gauss = gkern(10);
%a5
%plot(gauss); 
%the kernel is 1 by 33, and it is not normalized.

%a7
gauss2d = gauss'*gauss;
%since sum(sum(gauss2d)) is 1, it is normalized

%a8
%%
% Soon we will use a 2D gaussian box kernel on the image. First, see the kernel
% visualized below as a surface plot and an image.
surf(gauss2d);
title('Plot of 2D Gaussian');

%a9 - 
figure;
imshow(gauss2d, []);
title('Image of 2D Gaussian');


%b1-2
%%
% Applying a simple 1D seperable 1x10 boxcar filter onto the orginal image,
% we get the image below. The image becomes overall smoother and more 
% blurry, but we also lose tremendous detail. We find that artifacts, 
% including whiskers and the nose area, get blurred the most. These are the
% areas that have the largest local contrasts. We will discuss this blur at
% more length when contrasting it with the Gaussian filter.

bcFilter = conv2(boxcar,boxcar,img,'same');
figure;
imshow(bcFilter);
title('Seperable 1D Boxcar Filter Image');
%the picture becomes overall smoother and more blurry, but we also lose 
%tremendous details. We find that artifacts including whiskers, eyes, and noses get blurried the msot.
%These are the areas that has the local largest contrasts.

%%
% We use the same seperable method to apply a 1x33 gaussian filter onto the
% original image.
gaussFilter = conv2(gauss,gauss,img,'same');
figure;
imshow(gaussFilter);
title('Seperable 1D Gaussian Filter Image');

%%
% Comparing the images, in the macro scale, they have a similar blur around
% the whiskers, eyes, and nose using either a Box-filter or Gaussian. 
% However, when we zoom into the micro scale, the Box-filtering preserves 
% the lines in the fur showing the direction of the hair while the 
% Gaussian-filtering does not and certainly looks smoother. When it comes 
% to the eyes, there’s a thin black circle around the iris of the eye, 
% on the top of the eye white, with the Box-filter while the 
% Gaussian-filtering’s eye doesn’t and has a smoother transition between
% the iris to the eye whites and the black eye edges.

%%
% Further, the Gaussian filter maintains the shape of the pupils in the 
% eye, blurring it out slightly, while the box filter spreads it out into 
% a cross. The largest determinant for us was the blur of the nose. The 
% Box-filter shaded the area around the nose with a “shadow”. The Gaussian
% filter smooths the boundary but does not stretch the nose out and distort
% the shape. Because the Gaussian filter maintained shape and smoothed 
% edges better, we judge the Gaussian to be a superior blurring filter.

%%
% Now we move to the run time of seperable 1D kernels versus a 2D kernel.
% First, we see the run time using the seperable kernels.
tic;
conv2(gauss,gauss,img,'same'); % 0.001172 seconds. O(2K)
toc;

% time of gauss2d
%%
% Second, the run time using the 2D kernel.
tic;
conv2(img,gauss2d,'same'); % 0.010757 seconds. O(K^2)
toc;
%%
% The exact run times vary slighlty, but in our original test, the 
% separable 1D filtering took around one-tenth of the time the 2D filter
% took. K is the size of one dimension of our kernel, which is 33 in this
% case. The theoretical run time with the separable filter is 2K=66, 
% while the 2D filter has a theoretical run time of K^2=1089. 
% This gives us K^2/2K = 16.5; or in other words, the separable version 
% should be 16.5 times quicker. With this in mind, we see that the 2D 
% filter is not as comparably bad as the theory would suggest in this case.


%% C
img2 = imread("/home/weinman/courses/CSC262/images/legal.png");
img2 = im2double(img2);
img2inv = 1.0-img2;
template = im2double(imread("template.png"));
template = 2*template - 1;

result = filter2(template,img2inv,'same');
%%
% Now we move to identifying areas of correlation in an image. We use this
% to find nearly all the "t"s on an image of a legal document. First, we
% copy a croped section of the image containing a "t", and then running
% that template image in correlation equation aggainst every region of
% the full image. The first image below is the original image, and the second
% image shows white points in areas of correlation greater than 1.
subplot(1, 2, 1);
imshow(img2);
title("Original Image");
subplot(1, 2, 2);
imshow(result);
title("Correlation Image");

%%
% Our correlation image shows many locations of positive correlation 
% across the page, especially the stripe on the right side of the image.
% Displaying it with just the 0-1 scale, we also see numerous letters 
% (not all of which are t). The response was about as inclusive as expected.
% All of the locations of the t’s (outside the sidebar on the left) were
% marked, and so were many similar characters and shapes.


test = sort(result);
test2 = test(:);
test3 = sort(test2);
%[rows, cols] = find(result>2);
%[rows5, cols5] = find(result>5);
%plot(cols5, rows5, 'b+');
%title('Place where threshold is above 5');
%xlabel('x');
%ylabel('y');
%above we tested various thresholds, and we found that the values 2, 5, and
%8 all gave false positives.
[rows10, cols10] = find(result>10);
figure;
imshow(img2);
hold on;
plot(cols10, rows10, 'r+');
title('Result of detecting the leter "t"');

%%
% Above we overlay marking onto the image of places with a high enough 
% corelation to be a "t". We tested marking the image using a threshold of 
% 2, 5, 8, and 10. 
% Not until the threshold of 10 were all false positives eliminated. 
% Significantly, however, “t”s on the sidebar to the left were not caught 
% by this recognition system, as they were of a different orientation and 
% shape. Thus, while the “t”s of the same format as our template image all
% were successfully identified, other “t”s were ignored. The threshold of 
% 8 gave almost no false positives at all, but a couple of f’s and r’s did 
% get marked. The threshold of 2 and 5 highlighted practically any letter 
% with a similar shape to t, and would not even have been helpful 
% even as a pre-filtering for a human.


%c15 - we detected every t with the threhold 8 but we got a few false
%positives. With the threshold 10, we eliminated false positives but
%dropped a couple ts.
%% Extra Credit

extraImg = imread('onion.png');
extraImg = im2double(extraImg);


extraR = extraImg(:,:,1); % Red
extraR = conv2(gauss,gauss,extraR,'same');
extraG = extraImg(:,:,2); % Green
extraG = conv2(gauss,gauss,extraG,'same');
extraB = extraImg(:,:,3); % Blue
extraB = conv2(gauss,gauss,extraB,'same');

extraBlur = cat(3, extraR,extraG,extraB);
extraDiff = extraImg - extraBlur;
extraUnsharp = extraImg + 1.2*(extraDiff);
%%
% Finally, we move on to a type of image enhancement called sharpening. We
% achieve this with a process called unsharp marking. Unlike the rest of
% the lab, this was done in color, which required we exctract and preform
% operations on each color field individually in the process. We chose a 
% gamma of 1.2 for our unsharp masking, and it was probably still too much.
% The edges around bright spots got extremely amplified by the filtering 
% of the image with the separable gauss filter applied along each color
% field independently. The difference image of each color field combined
% was harder to distinguish on the black background as the black and white
% lines had been from a difference image taken from grayscale. 
% Ultimately, the unsharpened masking added what seems qualitatively 
% like an excellent improvement, even if the choice of gamma=1.2 was not 
% a good one. 
subplot(2, 2, 1);
imshow(extraImg); % from matlab built-in picuture
title("Original Image");
subplot(2, 2, 2);
imshow(extraBlur); 
title("Blurred Image");
subplot(2, 2, 3);
imshow(extraDiff); 
title("Difference Image");
subplot(2, 2, 4);
imshow(extraUnsharp);
title("Unsharp Masking Image");
% 
%% Conclusion
% We began the lab by comparing qualitatively Box-filtering and 
% Gaussian-filtering. We found that the Gaussian filter smoothed the image
% better than the Box filter. The Gaussian filter smoothed edges, like 
% those around the nose and the pupils, while the Box filter extended 
% those shaded areas into surrounding ones. Additionally, the Box filter 
% preserved the striping in the fur where the Gaussian smoothed that 
% striping away. 
% Theoretically, two separable 1-D Gaussian kernels should outperform the
% 2-D Gaussian kernels by a factor of K/2 (where K is length of one 
% dimension of the kernel), which we found by comparing the 2K and K^2 run 
% times of the two techniques respectively. However, likely due to 
% optimization in the 2D filter, our true value was that the two 
% separable 1-D kernels only ran roughly 10 times faster than the 2-D 
% Gaussian kernel in this case. 
% Using a threshold of 10 in the correlation, we find all the ‘t’s 
% instances in the given text image. When the threshold number is small, 
% similar characters like ‘r’, ‘f,’ and even vertical lines on the side are
% counted as ‘t’s. However, this method has limitations on the orientation
% of the sample. If the letter ‘t’ is placed horizontally or is in a 
% different font (like the ones on the left sidebar of the page), this 
% method doesn’t detect it since the vectorized region of the other ‘t’ is 
% not very similar to the vector of the sample ‘t’, resulting in a dot 
% product less than our threshold.
% Lastly, by using the unsharp masking method with a gamma value of 1.2, 
% we increased an image’s contrast. However, we found that this gamma value
% over emphasized the bright regions of the image in a way not ideal for a 
% human viewer. Since the gamma value is just a scalar to the difference 
% image, this indicates that scaling the difference image by more than 1 
% may add too much back into the image.



%% Acknowledgement
% The raw pictures are provided by MatLab.
%
% The Matlab markup guide: https://www.mathworks.com/help/matlab/matlab_prog/marking-up-matlab-comments-for-publishing.html
%
% Code are from the lab manual page: https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/filtering.html