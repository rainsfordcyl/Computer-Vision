%% CSC 262 Lab: Image Formation
%
% CSC 262

%% Overview
% In this lab, we calculate the estimated acquisition noise of a set of
% photos, and generate a graph with image mean value plus/minus one
% standard deviation (noise).

%% A. Observing the Image

%%
% The image read: 

% read the picture (this line should not be published)
cd /home/weinman/courses/CSC262/images/raw/
imgs = rawread('pic1.raw');
imshow(imgs);

%%
% After enlarging the picture, we can see a checkerboard-like pattern. We
% learned that the pattern is due to the different sensitivity to different
% wavelengths of light of adjacent sensors. 

% allocate the memory by making 10 slices
imgs(end,end,10) = 0;

% read in the pictures using a for-loop
for  k=1:10
  imgs(:,:,k) = rawread(['pic' num2str(k) '.raw']);
end

% calculate the standard deviation
imgs = im2double(imgs);

% find mean brightness of each pixel
imgMean = sum(imgs, 3)/10;

% a 3D matrix of differences in brightness with mean
imgDiff = imgs - imgMean;

% difference squared
imgDiffSqr = imgDiff .^ 2;

% variance
imgVar = sum(imgDiffSqr, 3)/(size(imgDiffSqr, 3) - 1);

% standard deviation
imgStdDev = sqrt(imgVar);

%% B. Noise Analysis
% This is the image of noise. The brighter the pixel, the bigger the noise.

% showing the image
figure;
imshow (imgStdDev, []);

%%
% From this image, we can see that most of the white pixels are between 2
% objects (i.e. noises are on the edges). We think it is due to the mixed
% pixel problem, where the pixel values are not completely independent of
% each other, which generates noise. For example, the white pixels on top
% of the nearest chair indicate noises. The pixel values there are not
% consistent between pictures because the pixel values there are an average
% of the color of this chair and the back of other chairs. 

%%
% This is a plot of the brightness of the middle row of the mean-image:

% Open a new figure window
figure;
plot(imgMean(end/2,:));

%%
% The curve appears to be bumpy because of the difference in sensitivity of
% adjacent sensors we mentioned before. We can solve this problem by
% plotting alternative pixels (here we plotted the odd-indexed pixels): 

imgOdd = imgMean(end/2, 1:2:end);
figure;
plot(imgOdd);

% keep the plot
hold on;

% extract the odd pixcels in the mid row of the standard deviation image
stdOdd = imgStdDev(end/2, 1:2:end);
plot(imgOdd+stdOdd);
hold on;
plot(imgOdd-stdOdd);

% label the x and y axis
xlabel Column;
ylabel Brightness;

% add the title
title ('Brightness of odd pixels in the middle row plus/minus stdDev');

% add legends
legend('original brightness', 'brightness + stdDev', 'brightness - stdDev');

%%
% This is the curve of brightness with +/- noise over the whole row of 
% pixels. We made measurement at 3 points to roughly calculate the average
% gray level difference between the mean+noise and mean-noise curves. The
% data is shown below:
% 
% (x is the position of the pixel)
% 
% * x = 22: gray level difference: 6.36
% 
% * x = 72: gray level difference: 4.73
% 
% * x = 615: gray level difference: 4.22
% 
% average gray level difference: 5.10

%%
% For the average noise over all the pixels, we summed up the standard 
% deviation matrix and divide the sum by the number of pixels with command
%
% sum(imgStdDev, 'all')/(size(imgStdDev, 1)*size(imgStdDev, 2));
% 
% Since the final result is a double between 0~1, we need to multiply it by
% 255 to get the 8-bit noise value.
% average noise over all pixels: 0.0085*255 = 2.17 

%% Conclusion
% We learned how to use the algorithm EST_NOISE to estimate the noise level
% in a set of pictures. Characteristics within a picture, such as sharp
% transition of pixel brightness, could be captured by the matrix operation
% and represented noise.

%% Acknowlegement
% The raw pictures are provided by Professor Weinman. The other provided
% code are from the lab manual page: https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/image-formation.html#enu:Noise-Levels