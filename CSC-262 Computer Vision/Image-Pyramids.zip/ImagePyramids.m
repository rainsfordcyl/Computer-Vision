%% CSC 262 lab: Image Pyramids
%
% CSC 262

%% Overview
% In this lab, we create a Gaussian pyramid of a brick image with different
% levels by blurring and downsampling the image on each level. We find an
% appropriate scale of 1.75 by exploring the magnitude of the Fourier
% transform of the Gaussian kernel and adjusting the scale to keep the
% details of the image and prevent aliasing at the same time. Furthermore,
% with the Gaussian pyramid technique, we use the Laplacian of Gaussian
% kernel to search for large features at coarser scales in a sunflower
% image and find that the false positive rate decreases as the scale
% becomes coarser.

%% Gaussian pyramid with a proper scale

%%
% We first import the brick image from professor Weinman. Then, we convert
% it to the grayscale image in double. Then, we create the image pyramid
% using the function gausspyr of level two. This function first uses the
% Gaussian kernel of scale 1.75 to blur and downsample the previous layer
% of the image.

% The raw image is provided by Professor Weinman
brkImg = im2double(imread('/home/weinman/courses/CSC262/images/bricks.jpg'));
grayscaleBrk = im2double(rgb2gray(brkImg));
figure;
imshow(grayscaleBrk);
title('The grayscaled Brick image');

brkPyr = gausspyr(grayscaleBrk, 2);
figure;
imshow(brkPyr{1});
title('The second level of Brick Image in the pyramid');

%%
% The reason for blurring the image first is to block the high frequency of
% the image where aliasing happens. The highest frequency of an image is
% 0.5 cycles per pixel. In order to avoid as much aliasing as possible, we
% need to kill off the high frequency while keeping the low frequency by
% using the Gaussian kernel. The scale of the gaussian kernel determines
% how much high frequency we could kill off. The larger the scale is, the
% more high frequency we could block by introducing the effect from the
% neighbor pixels. However, high frequencies usually contain the fine
% detail of the image. So, we do not want to have a scale as large as
% possible. Instead, we pick an appropriate scale by looking at the Fourier
% transform of the Gaussian kernel.

% The code is obtained from "Lab: Image Pyramid" by Professor Weinman
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/image-pyramids.html
scale = 1.75;
gauss = gkern(scale^2); % Gaussian kernel with sigma=1.75
fftGauss = fftshift(fft(gauss)); % 1-D FFT, has  scale/1.75 in freq domain.
frequencies = linspace(-0.5,0.5,length(fftGauss));
figure;
plot(frequencies,abs(fftGauss));
xlim([-0.5,0.5]);
title('Fourier Transform of the Gaussian kernel');
xlabel('Frequency of the kernel (cycle/pixels)');
ylabel('Magnitude of the kernel');

%%
% Since we downsample each image's size by half for each level, aliasing
% happens in the high-frequency range above 0.25 and below -0.25. When the
% kernel scale is 1.75, we keep most of the low frequency ranges from -0.25
% to 0.25. At the same time, we still block almost all of the
% high-frequency range. However, we did not choose a scale value larger
% than 1.75 because we will lose some fine details between the brick of the
% image. We did not pick a scale less than 1.75 because we only wanted to
% keep the minimum amount of high frequency in our image to prevent
% aliasing from happening.

%% Application of Gaussian pyramid with Laplacian of Gaussian kernel

%%
% Image pyramids are often used to search for large features at different
% scales. We will use the Laplacian of Gaussian pyramid to detect blobs in
% the sunflower image provided by Professor Weinman. The original sunflower
% image is shown below.

% The raw image is provided by Professor Weinman
sunfImg = im2double(imread('/home/weinman/courses/CSC262/images/sunflowers.png'));
figure;
imshow(sunfImg);
title('The grayscaled sunflower image');

%%
% Unlike the Gaussian kernel, the Laplacian of Gaussian kernel kills off
% very high and low frequencies but keeps frequencies in between. With this
% kernel, we can detect the edges of objects in the image by looking at the
% remaining frequencies.

gauss2 = gkern(4^2);
gauss2dev = gkern(4^2, 2);
sunfGausspyr = gausspyr(sunfImg, 4);

convSunf_1 = conv2(gauss2, gauss2dev, sunfGausspyr{1}, 'same');
convSunf_2 = conv2(gauss2dev, gauss2, sunfGausspyr{1}, 'same');
convSunf = convSunf_1 + convSunf_2;

for i = 1:4
    imgpyr = gausspyr(sunfImg, i);
    imgpyr_1 = conv2(gauss2, gauss2dev, imgpyr{1}, 'same');
    imgpyr_2 = conv2(gauss2dev, gauss2, imgpyr{1}, 'same');
    imgpyr_combine = imgpyr_1 + imgpyr_2;
    figure;
    imshow(imgpyr_combine, []);
    threshold = 0.005;
    imgpyr_binary = imgpyr_combine > threshold;
    hold on;
    % The code is obtained from "Lab: Image Pyramid" by Professor Weinman
    % https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/image-pyramids.html
    contour(imgpyr_binary, [1,1], 'red');
    title('Sunflower Image in the pyramid with level' + " " + string(i));
end

%% 
% The threshold that we pick is 0.005. First, we look at the original
% picture in grayscale. We predict that edges between the sunflower and its
% background appear around two areas. One is the inner part of the petals
% to its seed in the flower's center. The other edges is around the outer
% part of the petals to its surroundings. Applying the Laplacian of
% Gaussian kernel to the image, we divide the image into three areas: the
% bottom area, the middle area, and the top area.

%%
% We first analyze the bottom part of the image. This area contains four
% relatively larger sunflowers. In the finer scales, it detects the blobs
% very well, showing the finest change between every single petal on the
% outer edge of the sunflower. The contoured area around the petals becomes
% larger as the image becomes coarser.

%%
% This could be explained by the threshold we picked for the Laplacian of
% Gaussian kernel. The gaussian kernel first smoothed the image by killing
% off the high-frequency areas, causing the overall image to become darker.
% Therefore, the local change of pixel frequencies is expanded, causing the
% contoured area to become larger.

%%
% For instance, comparing the brightness of the outer petals of the
% sunflowers in level 1 and level 3, the edge of the area becomes dimmer,
% and the contours around the petals also become larger.

%%
% Another noticeable artifact is the expansion of the contoured inner seeds
% area of the sunflower. In the first level, the contoured areas between
% the inner petals and the seeds are separated and isolated from each
% other. However, in the third level, the same artifacts are connected,
% forming a discontinuous contoured ring shape in the sunflower's center.

%%
% Then, we analyze the middle part of the image. This area contains about
% 14 sunflowers, including the sunflower facing on the side. Other than the
% similar trend we discussed above. It has new artifacts, a rotated
% sunflower. In the finner level, the rotated sunflower's contoured area
% mostly matches the shape of the rotated sunflower. 

%%
% For example, in the rotated sunflower's mid-right part, two contoured
% boundaries are relatively parallel to each other. Besides, it forms the
% shape of an ellipse. However, the two parallel boundaries are mixed into
% one larger contoured area at the coarser level. As a result, the eclipse
% contours around the rotated sunflower also become more circular now.

%%
% Another noticeable change is that the contoured area between each
% sunflower's petals becomes larger and coarser, ignoring the detailed
% corner between each petal. This could be explained by the same reason we
% mentioned in the analysis of the bottom part above.

%%
% Lastly, we analyze the top part of the image. This area contains even
% more sunflowers. On the finest scale, sunflowers are still clearly
% recognized. In the first and second levels, sunflowers are represented by
% the ring-shaped contour formed by a circle representing the seed area and
% a ring representing the petal of the sunflower. On the top left corner,
% the first level even recognized the rotated sunflowers that stay up high
% and extend to the sky. However, the coarser level, the third and fourth
% level, only has a rough contoured area on the seed area of the flower,
% forming a whole circle or even other irregular shapes to represent the
% sunflower. Some parts even contour the area between two flowers other
% than forming a circle within the sunflower area.

%%
% As the scale changes from fine to coarse, the false positive rate
% decreases in the bottom part of the image. False positive in this image
% means that the algorithm recognizes part of an image as a sunflower, but
% it is not. As the scale becomes coarser, as we explained in the analysis
% of the bottom part image, the image overall becomes darker, where small
% contrasts between the sunflowers are less likely to be recognized as the
% contour of the sunflower. For example, on the first level of the pyramid,
% several isolated small contours surround the bottom middle part of the
% sunflower leaves. However, in the second level, the number of the small
% contours in the same area decreases. In the third level, the number of
% the small contours decreases even more than finally fades in the fourth
% level.

%%
% Besides the obvious trend we find above, another interesting artifact
% appears on the top part of the image. In the finer scale, the algorithm
% almost detects all the contours of the small sunflowers. However, in the
% coarser scale, the third and fourth level, red contours of the area in
% between different flowers are shown. However, it shouldn't be treated as
% a false positive since these contours still surrounds the sunflower from
% the outside.


%% Conclusion
% In creating our Gaussian pyramid of the brick image, we found a trade-off
% between keeping the datails of the image and reducing aliasing in
% determining the scale of our pyramid. Due to the trade-off, it was
% difficult to find the perfect scale that keeps every detail of the image
% and completely prevents aliasing. However, we could find the proper scale
% by adjusting it based on the magnitude of the Fourier transform of our
% Gaussian kernel. In addition, using the Gaussing pyramid, we searched for
% some large features at coarser scales in the sunflower image. In the
% sunflower image, our Laplacian of Gaussian kernel with our threshold
% detected sunflowers at different scales. The overall flowers were
% detected well with the distinct red contour in the finner scale. However,
% in the coarser scale, the contour around the flowers got discontinued and
% expanded. This makes sense because the image is smoothened on each level
% of our pyramid. Besides the change in the contour, the relatively small
% flowers in the top part of the image were not detected anymore for the
% same reason. In the last part of the lab, we observed that the false
% positive rate decreases as the scale becomes coarser.

%% Acknowledgement
% The raw pictures are provided by Professor Weinman.
%
% The Matlab markup guide:
% https://www.mathworks.com/help/matlab/matlab_prog/marking-up-matlab-comments-for-publishing.html
%
% Code are from the lab manual page:
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/edges.html