function [pyramid] = gausspyr(img,level)
% GAUSSPYR Creates a Gaussian pyramid of 'level' of the 'img.'
%
% [pyramid] = GAUSSPYR(img, level) where 'img' is a grayscale images and
% 'level' is a number of levels to compute. This function's output is a
% cell containing the scale-adjusted pyramid of 'img' and the level. We
% first create a gaussian kernel of scale 2.25, applying the kernel to the
% first level of image (starts from the given 'img'), then downsample the
% image, producing the next level of the image and loop the procedure above
% the number of 'level' times.
%
%
% CSC 262 Lab: Image Pyramid

scale = 1.75;
pyramid = {im2double(img), level};

for i = 2:level
    gauss = gkern(scale^2);
    % smoothing the image using fourier transform
    smoothImg = conv2(gauss, gauss, pyramid{1}, 'same'); 
    downsampleImg = smoothImg(1:2:end, 1:2:end);
    pyramid{1} = downsampleImg;
end

end

