%% CSC 262 lab: Local Operators
%
% CSC 262

%% Overview
% Today we explore different ways to process an image, including
% gamma-correction, linear transformation, and histogram equalization. 

%% A. Pixel Transforms

% load the image from Matlab and then show it
demo1 = imread("cameraman.tif");
imshow(demo1);

% convert the 8-bit format picture into a double version
demo1d = im2double(demo1);

%%
% The picture above is the source that we will deal with in the next
% section. We first represent each pixel of the image in double (from zero 
% to one) type. 

%%
% *A.1 Gamma Correction*
% 
% Now, we apply gamma-correction to the source picture (in
% double type) with gamma value of 2.2. The expression of Gamma-correction
% is shown:
%
% $$ g(x)=[f(x)]^{1/\gamma}$$
%

% process the image using gamma correction with gamma = 2.2
gamma = 2.2;
demo1dGamma = demo1d .^ (1/gamma);

% plot the gamma-corrected image
figure;
imshow(demo1dGamma);

%%
% We notice that the overall picture appears to be brighter. The darker it 
% was before, the more brightness will be given after. This is because when
% both the index (1/gamma) and the base is between zero and one, the result
% will be greater than the original base, with smaller base increasing by a
% larger amount. For example, when the original pixel value is 0.2, after 
% gamma-correction, we have 0.2^(1/2.2) = 0.48, while for a brighter pixel,
% with brigtness of 0.9, we have 0.9^(1/2.2) = 0.95 which increases by a
% smaller amount.

%%
% *A.2 Linear Transformation*
%
% Other than gamma-correction, another way to transform the image is using
% linear transformation. There are two ways to adjust this, which are gain 
% adjustment (a) and bias adjustment (b). The linear transformation is 
% shown as:
%
% $$g(x) = af(x)+b$$
%
% In this image below, we apply a bias of 0.3.

% apply a linear transformation bias of 0.3 to the orginal picture
bias = 0.3;
demo1dLinearBias = demo1d + bias;

% plot the bias-processed picture
figure;
imshow(demo1dLinearBias);

%%
% Besides that each pixels become brighter, the constrast of the picture 
% decreases, because darker pixels become brighter, while the white pixles 
% with a orginal value greater than 0.7 reaches a upper limit of 1. So, the
% overall contrast decreases.

%%
% Another way of using Linear Transformation is through adjusting gains. We
% apply a value of 1.3.

% apply a linear transformation gains of 1.3 to the original picture
gains = 1.3;
demo1dLinearGains = demo1d * gains;

% draw the processed image
figure;
imshow(demo1dLinearGains);

%% 
% We noticed that the contrast of the picture increases, because after each
% pixel being multiplied by a certain number (1.3 in this case), the 
% brighter value increases more while darker value increases by a less 
% amount.

%% B. Histogram
% We often use histograms to show the distribution and frequency of
% different brightness. The following is a histogram of the original
% picture: 

% saving the histogram data
demo1hist = hist(double(demo1d(:)), 256);
% showing the histogram
figure;
bar((0:1:255), demo1hist);
xlabel("Brightness");
ylabel("Freq");
title("Histogram of cameraman.tif");

%%
% Brightness=7 has the most pixels. We expect most detail to emerge from 
% the range around 13~100 and 200~255 because the frequency of these 2 
% ranges will be brought high by the equalization.

%% C. Histogram Equalization
% In this section, we apply histogram equalization to the image. 
%
% The following is a graph of the cumulative distribution function
% calculated from the histogram in the previous section: 

% calculate the cumulative sum of the histogram we created in the previous
% section and the plot it.
demo1CDF = cumsum(demo1hist);
figure;
plot((0:255),demo1CDF);
xlabel("Brightness");
ylabel("Cumulative Freq");
title("Cumulative Distribution Function");

%%
% From the graph, we can see that there is a steep slope ranging from
% brightness 0~10 and 153~190, a diagnal slope between 11~95, and a
% nearly horizontal slope between 195~255. The greater the histogram value,
% the greater the slope of the CDF. For using the CDF as a transfer
% function, the part where there are lots of pixels of the similar
% brightness will be higher than the y=x transfer function, which means the
% brightness of those pixels will increase, and eventually smoothen the CDF
% curve.

% make the CDF into a transfer function
CDFmap = demo1CDF/256;
% scaling by rounding and subtract by 1 and cast
CDFscaledMap = uint8(ceil(CDFmap)-1);

%%
% After scaling down, the range of the new function is 0~255. The graphs is
% as followed (with y=x as reference): 
figure;
plot((0:255), CDFscaledMap);
hold on;
plot((0:255), (0:255));
xlabel("Original Brightness");
ylabel("New Brightness");
title("CDF transfer function");
legend("CDF transfer function","Identity transfer function");

%%
% Then we apply the equalization: 

% map the original picture to the CDFscaled Map (to get the equalized
% image) and then show it
demo1Eq = CDFscaledMap(demo1+1);
figure;
imshow(demo1Eq);

%%
% We can now see that there are stripes in the sky that become accentuated
% after histogram equalization. The transition of boundaries becomes
% sharper. 

% Making the histogram of the new picture
demo1EqHist = hist(double(demo1Eq(:)), 256);
figure;
bar((0:1:255), demo1EqHist);
xlabel("Brightness");
ylabel("Freq");
title("Equalized Histogram of cameraman.tif");

%%
% This is the new histogram after equalization. We can see that the peak
% at brightness 161 in the original histogram is now much smoother.
% However, what we did not expect is that there is now a higher peak 
% (15, 3214) in the lower brightness range, even though the original peak
% at (7, 1685) disappeared. 

%% D. Blending Maps
% In this section, we explore the effect of a blend map by combining the
% CDF transfer function in last section and an identity transfer function.
% This is how the blended transfer function looks like (alpha = 0.75): 

% creating an identity transfer fx
idMap = uint8((0:255));

% set a alpha value of 0.75
alpha = 0.75;

% create the blended map that is the weighted avearge of CDF scaled map and
% the identity map of alpha = 0.75.
blendedMap = alpha*CDFscaledMap + (1-alpha)*idMap;

% plot the blended map and the orginal map, and then compare
figure;
plot((0:255),blendedMap);
hold on;
plot((0:255),CDFscaledMap,'k--');
xlabel("Original Brightness");
ylabel("New Brightness");
title("Blended transfer function");
legend("blended transfer function", "old CDF transfer function");

%%
% From the graph, we can see that the blended function appears to be
% relatively milder(closer to the identity transfer function) than the old
% CDF transfer function. 
%
% This is how the image look like after being mapped to the blended
% transfer function:

% map and then show the blendedMap to the orginal image
demo1blend = blendedMap(demo1+1);
figure;
imshow(demo1blend);

%%
% Based on the plot comparing the original CDF scaled map and the blended
% map, we predict that the new graph would have less contrast. However,
% based on our observation, we do not see any obvious distinction between
% the two pictures. This may due to the low resolution of the monitor.
%
% The histogram of the image after mapping with the blend map: 

% create the histogram of the new blended picture
demo1BlHist = hist(double(demo1blend(:)), 256);
figure;
bar((0:255), demo1BlHist);
xlabel("Brightness");
ylabel("Freq");
title("Equalized Histogram of cameraman.tif (Blend)");

%% Conclusion
% We used gamma-correction, linear transformation, and histogram
% equalization to process the image. In gamma-correction, with a higher
% gamma value, the darker the original pixel is, qthe brighter it would
% become. In linear transformation, with a higher bias, although each
% pixels have a higher brightness, the contrast decreases as a result; with
% a higher gains, the brighter value increases more while darker value
% increases by a less amount. Finally, using histogram equalization, we
% would get a equalized image which balance the range of brightness of the
% overall picture, but it also sharpens the transition of edges. At the
% very end, we create a linear blend between the cumulative distribution
% function and the identity transform, however, we couldn't point out any
% obvious difference between the blended image and the CDFscaled image.

%% Acknowledgement
% The raw pictures are provided by MatLab.
%
% The Matlab markup guide: https://www.mathworks.com/help/matlab/matlab_prog/marking-up-matlab-comments-for-publishing.html
%
% Code are from the lab manual page: https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/local-operators.html#enu:histeq-image