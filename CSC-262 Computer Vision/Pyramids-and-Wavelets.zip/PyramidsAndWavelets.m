%% CSC 262 lab: Pyramids and Wavelets
%
% CSC 262

%% Overview
% In this lab, we use a Laplacian pyramid to compress an image. In the
% process of compression, we extract the high-pass band from the Laplacian
% of Gaussian (LoG) pyramid and analyze the histogram of the high-pass
% coefficients. Then, we find the threshold of 0.0581 to eliminate about 80
% percent of pixels in the high-pass band and save some space by only
% storing the remaining pixels. In order to check the accuracy of our
% compression method, we also compare the reconstructed original and
% compressed images and their RMS values. Besides the Laplacian pyramid, we
% also explore a steerable pyramid and its high-pass band. In the end, we
% find that the Steerable pyramid stores the LoG in different orientations,
% which is suitable for analyzing features but suffers from the lack of
% spatial localization within the orientation factor.

%% Laplacian Pyramid
% As we saw in the previous lab, a Gaussian pyramid uses a low-pass filter
% to smoothen and downsample an image. Keeping low frequencies and killing
% off high frequencies can create the same image at different scales while
% preventing aliasing to some extent in the process. With this feature of
% the Gaussian pyramid, a Laplacian pyramid uses a high-pass filter by
% calculating the difference between the smoothened image and the original
% image in each level of the Gaussian pyramid. Since the difference
% contains the high frequencies that are lost in blurring, the Laplacian
% pyramid can keep high frequencies, kill off low frequencies, and show
% edges on the image.

% The raw image is provided by Matlab
img = im2double(imread('cameraman.tif'));
figure;
% The code is obtained from "Lab: Pyramids and Wavelets" by Professor Weinman
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/pyramids-wavelets.html
[pyrValues, pyrDims] = buildLpyr(img, 4);
% Add the pyramids number of pixel in each level and you get the pyrValues

% The code is obtained from "Lab: Pyramids and Wavelets" by Professor Weinman
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/pyramids-wavelets.html
showLpyr(pyrValues, pyrDims);
title("Laplacian Pyramid of the Image with four levels");

%%
% Our Laplacian pyramid’s height is four, and the original image size is
% 256*256. As we expected, the resulting image is 32*32 because the image
% size in each level is ¼ of the size in the previous level. The length of
% the pyramid vector is 87040 = 256^2+128^2+64^2+32^2 because the pyramid
% contains images at every level. Our Laplacian Pyramid has three
% edge-detailed images and one compressed image. Since the Laplacian
% pyramid keeps the high frequencies that are lost in blurring in the
% Gaussian pyramid, the image in each level still contains details, and the
% compressed image also has details without as much blurriness as the
% Gaussian pyramid.

%% Analysis of high-pass band in Laplacian Pyramid
% Now, we explore the high-pass coefficients of our Laplacian pyramid. The
% histogram of the Laplacian high-pass coefficients is shown below.
boundary = unique(pyrDims(:, 1));
boundary = boundary(2:end);
boundary = sum(boundary.^2);

highBand = pyrValues(1:boundary);
lowBand = pyrValues((boundary+1): end);
numberOfBins = 100;
hist(highBand, numberOfBins);
xlabel("Brightness of the Highpass band");
ylabel("Frequency");
title("Histogram of Laplacian high-pass Coefficients");

%%
% The histogram seems similar to the Gaussian curve, which is bell-shaped
% with a high number of counts at the center. It is the shape we expected
% because the Laplacian pyramid keeps high frequencies and kills off low
% frequencies by subtracting the smoothened image from the original image.
% Since the blurring process of the Gaussian pyramid keeps low frequencies
% and eliminates high frequencies, the difference between the blurred and
% original images keeps high frequencies and eliminates low frequencies.
% This indicates that the difference only contains high frequencies, only
% edges become distinct, and the other areas on the image become nearly 0.
% As shown in the pyramid, non-edge areas are much bigger than edges, so
% most Laplacian high-pass coefficients are nearly 0 except those
% corresponding to the edges. As a result, the histogram has high
% frequencies of 0 at the center and low frequencies of other intensities
% representing edges around the center. 

%% Image Compression using Laplacian Pyramid
% A Laplacian pyramid is used to compress an image, and the compressing
% process often keeps only high intensities and eliminates low intensities
% that are difficult to recognize. Therefore, we can save some space from
% the removed low intensities in such a technique.  
figure;
subplot(2,1,1);
plot(abs(highBand));
xlabel('Index');
ylabel('Brightness');
title("Unsorted high-pass band coefficients' magnitude");

sortedHighBand = sort(abs(highBand));
subplot(2,1,2);
plot(sortedHighBand);
xlabel('Index');
ylabel('Brightness');
title("Sorted high-pass band coefficients' magnitude");

threshold = sortedHighBand(round(length(sortedHighBand)*0.8));

highBand(highBand<threshold) = 0;

% The code is obtained from "Lab: Pyramids and Wavelets" by Professor Weinman
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/pyramids-wavelets.html
sparseHighband = sparse(highBand);
whos;
% highBand: 688128 bytes
% sparseHighBand: 133264 bytes

%%
% According to the sorted high-pass band coefficients’ magnitude graph,
% about 80 percent of pixels have a brightness of nearly 0. Since the
% pixels with such low brightness are difficult to recognize, we set the
% brightness of those pixels to 0 in order to save some space. We found
% about the 80th pixel, used its brightness of 0.0581 as a threshold, and
% finally stored only non-zero pixels with their indices. Initially, we had
% a total of 688128 bytes to store all the pixels. However, we needed
% 133264 bytes to store the pixels after this process. It is only about 20
% percent of the original space, so we saved about 80 percent of the
% original space. This is the expected result because we set about 80
% percent of the pixels to 0.

%% Image Reconstruction with Laplacian Pyramid
% A Laplacian pyramid is a good method to compress an image. However, we
% still need to check whether our compressed image includes enough
% meaningful information by reconstructing the image from our original and
% compressed representation and comparing them.
concatVec = [highBand; lowBand];

% The code is obtained from "Lab: Pyramids and Wavelets" by Professor Weinman
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/pyramids-wavelets.html
imgOriginal = reconLpyr(pyrValues, pyrDims);
imgRecon = reconLpyr(concatVec, pyrDims);

figure;
imshow(imgOriginal, []);
title("Original Image");
figure;
imshow(imgRecon, []);
title("Reconstructed Image");

RMSOriginal = sqrt(mean((imgOriginal - img).^2, 'all'));
RMSRecon = sqrt(mean((imgRecon - img).^2, 'all'));

%%
% The reconstructed compressed image is brighter overall than the
% reconstructed image. In addition, the edges become unsharpened on the
% reconstructed compressed image. In detail, the edges with the strong
% contrast on the reconstructed compressed image are more distinct and
% clear than the reconstructed image. In contrast, the edges with the weak
% contrast on the reconstructed compressed image are dimmer than the
% reconstructed original image. For instance, the contrast between the
% man’s coat and the background is very strong, and the reconstructed
% compressed image has a clear, bright edge. However, the contrast between
% the high building and the background is relatively weak, and it is
% difficult to see the edge of the reconstructed compressed image. This
% makes sense because we excluded about 80 percent of pixels in the
% high-pass band during the compression. Since the excluded pixels had low
% brightness and the remaining pixels had high brightness, the distinct
% edges become more distinct, and the dim edges become dimmer in the
% process of compression due to the lost pixels with low brightness in the
% high-pass band.

%%
% The RMS for the reconstructed original image is 2.6563e-18, nearly 0, and
% the RMS for the reconstructed compressed image is 0.0905. The RMS for the
% reconstructed compressed image is greater than that for the reconstructed
% original image. As seen in the Image Formation lab, the RMS of 0.0905 is
% still greater than the average and worst-case noises of cameras. This
% indicates that the details lost in the process of compression seem
% significant, so the threshold might not be tolerable for a good
% compression. To decrease the RMS, we might try a lower threshold to keep
% some more details.

%% Steerable Pyramid

%% 
% In order to explore the uses of the Steerable pyramid, we first built a
% steerable pyramid in our original picture. The steerable pyramid’s height
% and order are three. Order is one less than the number of orientations,
% so the orientation of the Steerable pyramid is four. The Steerable
% pyramid is displayed below. We should have 3 levels * 4 orientations + 1
% high-pass band and 1 lowpass residue = 14 images on our pyramid. However,
% the program omits the high-pass band.

%%
% Since it is the high-pass band on the first level, the high-pass band
% should not be oriented. Therefore, we predict the high-pass band image to
% have the same amount of white contour lines in all directions. 

% The code is obtained from "Lab: Pyramids and Wavelets" by Professor Weinman
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/pyramids-wavelets.html
[pyrValues, pyrDims] = buildSFpyr(img, 3, 3);

figure;
% The code is obtained from "Lab: Pyramids and Wavelets" by Professor Weinman
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/pyramids-wavelets.html
showSpyr(pyrValues, pyrDims);
title("Steerable Pyramid Image");

pause(1);

% The code is obtained from "Lab: Pyramids and Wavelets" by Professor Weinman
% https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/pyramids-wavelets.html
bandImage = pyrBand(pyrValues, pyrDims, 1); % 2 4 6 8 10 12
figure;
imshow(bandImage, []);
title("Non-oriented high-pass band Image");

%%
% Then, we display the high-pass band omitted from the Steerable pyramid.
% In general, it meets our expectations. As mentioned above, the high-pass
% band does not have a specific orientation. So, it would not ignore the
% edge in any orientation. For instance, focusing on the edge of the
% cameraman, the edge of the cameraman's right shoulder in the high-pass
% band is not as apparent as the edge of the same part shown in the first
% level of the Steerable pyramid oriented in the positive-y direction.
% Similar patterns also appear on the camera stand's diagonal edge, the
% background buildings' vertical edges, and even the grass on the ground. 

%%
% Besides, the aliasing effect is more evident in the high-pass band than
% in the diagonally oriented Image in the Steerable pyramid. An example
% would be the stand on the right side of the first leg of the camera
% stand. Vertical small white line segments represent diagonal stands.
% However, the line segments in the Image of the Steerable pyramid in the
% diagonal orientation are shorter and narrower than the lines in the
% high-pass band image. This is because when we take the oriented Image in
% a specific orientation, the edge change in that specific orientation is
% better preserved in the Steerable pyramid while blocking the effect from
% the other direction. This is contributed by using the Laplacian of the
% Gaussian pyramid in one direction. Therefore, it kills off more
% high-frequency in that direction. This helps reduce the level of aliasing
% happening in that direction.

%%
% In general, there are four orientations in the same level of the
% Steerable image: from bottom-left to top-right diagonal, from bottom to
% top, from bottom-right to top-left diagonal, and from left to right.
% Objects with more drastic changes in the same direction are better
% preserved in one orientation. For example,  in the first level, the
% leftmost image is the top-right diagonal orientation representation of
% the image. So, it is more sensitive to the change from the left-bottom to
% the right-top direction. It records the change of the right leg of the
% camera stands. However, it does not record the change from the
% right-bottom to the left-top. For instance, we could barely see the edge
% of the cameraman's right shoulder, whose change is oriented from the
% right-bottom to the left-top.

%%
%  Generally speaking, in the bottom-left to top-right diagonal direction,
% objects that have the same direction, including the right leg of the
% camera stands, the right forearm of the cameraman, the transition of the
% black coat to the cameraman’s white neck, and the bottom-left to
% top-right diagonal curved building stands out. In the top to bottom
% direction, the white line segments clearly represent structures like the
% upper and lower bound of the camera lens and the grass boundaries that
% change in the horizontal direction. Another noticeable artifact also
% happens in the right shoulder of the cameraman. The top to down
% orientation is more obvious horizontally than diagonally. The background
% building with pillars shows the same effect. In the top-left to
% bottom-right orientation, the left leg of the camera stand, the diagonal
% of the cameraman’s right arm, the right edge of his coat, both of his
% trousers’ edges, and vertical buildings in the back are structures that
% stand out. Finally, in the last left to right orientation, structures
% that have vertical components stand out. These include all the artifacts
% that have diagonal structure and a vertical structure, such as the edge
% of his coat, trousers, both stands of the camera, and the buildings in
% the back, especially the vertical pillars of the building and even the
% vertical structure of the grass in the foreground emerges.

%%
% Then, we analyze the pyramid between different levels. The change in that
% direction becomes more evident as we move from the finer scale to the
% coarser scale. For example, in the first bottom-left to top-right
% orientation, in the finest scale, the change of the curved building from
% the shaded area to the white roof is not very obvious. However, in the
% second level of the image in the same orientation, the white curve
% segment stands out more and even covers the pillars of the building
% beside it. Another noticeable change is the proportion of the line
% segments with the same filter orientation. For all the directions, as we
% move from fine-scale to coarse scale, the change in the same direction as
% the filter’s orientation augments and deepens the white color of the
% edges. Another example would be the grass in the foreground, as we move
% from the fine scale to the coarse scale, the segments of the grass in the
% direction of the orientation of the filter become more and more obvious,
% and in the third level, some grass is even represented by the continuous
% white line-segment. An example is the horizontal change of grass in the
% second column from left to right in the Steerable pyramid.

%% Steerable Pyramid excluding the Vertical/Horizontal Orientations

%%
% If we zero out the coefficients of all the horizontal and vertical
% oriented bands, we expect the images whose filter is oriented from top to
% bottom and from left to right to be completely gone. For the diagonal
% ones, we expect the white lines of the contour to be less obvious. We
% expect this phenomenon because it is the same as applying a Fourier
% transform to the image that kills off waves that lie in u and v axis. The
% filter band passes any frequency that is oriented horizontally and
% vertically. Therefore, unless the change is in the diagonal direction, we
% could not see anything for images in the Steerable image. When we
% reconstruct our image using the Steerable pyramid, places where artifacts
% transit drastically will be smoothed in gray instead of black and white.

pyrValuesNew = pyrValues;

for i=2:2:12
    % The code is obtained from "Lab: Pyramids and Wavelets" by Professor Weinman
    % https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/pyramids-wavelets.html
    bandIndices = pyrBandIndices(pyrDims,i);
    pyrValuesNew(bandIndices(1:end)) = 0;
end

figure;
showSpyr(pyrValuesNew, pyrDims);
title("Steerable Pyramid without horizaontal and vertical orientations");

reconImgNew = reconSFpyr(pyrValuesNew, pyrDims);
figure;
imshow(reconImgNew, []);
title("Reconstructed Image with Steerable Pyramid");

%%
% As we predicted before, the images in the pyramid mostly show the same
% pattern as we predicted above. However, we did not expect that some
% pixels in the diagonal direction are even sharpened instead of darkened.
% For instance, comparing the image in the non-zeroed pyramid in the
% bottom-left to the top-right diagonal direction to the image in the
% zeroed pyramid in the same direction, the right buildings’ edges in the
% background are more obvious in the zeroed pyramid than the same artifact
% in the non-zeroed pyramid. This is due to eliminating the horizontal
% gradients, weakening the effect, and decreasing the diagonal direction
% change. 

%%
% As the final product shows, there is a hazy area around the edge of the
% cameraman. Also, another noticeable effect is that the dark components of
% the trousers and coats from the cameraman's coat spills and overflows to
% the top left corner. The same effect also happens around the coat area
% and the cameraman's black hair. This is because, as described above, this
% is the same as taking the image's Fourier transform and eliminating the
% waves on u and v axis. Its drawback is the phenomenon of having these
% spillovers and bleeding effects around the edge of the image and
% artifacts. 

%% Conclusion
% In this lab, we explored the topic of Laplacian of Gaussian pyramid and
% Steerable pyramid. Instead of just storing the smoothed image in the
% pyramid as we did in the Gaussian pyramid, the Laplacian of the Gaussian
% pyramid stores the difference between the original image and the
% upsampled and blurred image. We find that it effectively stores the
% difference using less space than storing the whole picture determined by
% the threshold we set. We find the change between the reconstructed and
% original images by calculating the RMS of the two. We find that the RMS
% is around a reasonable value of 0.09. Therefore, the Laplacian of
% Gaussian pyramid could be used to compress the image into different
% scales. However, the Steerable pyramid is often used to analyze an
% image's features because it provides not only the image on different
% scales but also the orientations change on different scales. However, we
% should be careful with changing the coefficient of the Steerable pyramid
% since the filter's orientation is a global factor that has the drawback
% of having a bleeding effect, as we observed in the reconstructed image
% from the Steerable pyramid with only diagonal orientations.

%% Acknowledgement
% The raw image is provided by MatLab.
%
% The Matlab markup guide: https://www.mathworks.com/help/matlab/matlab_prog/marking-up-matlab-comments-for-publishing.html
%
% Code is from the lab manual page: https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/pyramids-wavelets.html