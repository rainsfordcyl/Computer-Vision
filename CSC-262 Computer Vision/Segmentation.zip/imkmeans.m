function [labels, centers] = imkmeans(data,K)
%IMKMEANS takes an image and try to assign the image into K number of
%clusters and assign the average color of the same number of clusters into
%that cluster set
%
%   DATA is the NM * 3 matrix reshaped from a N * M * 3 image
%   K is the number of clusters
%   
%   LABELS is the cluster assignment
%   CENTERS is a K by 3 matrix that returns each row consists of the
%   corresponding average color for that cluster set. If no pixles are
%   assigned to a corresponding cluster set, then a random color would be
%   picked.

maxIteration = 30;

reshapeImg = reshape(data, [], 3);

currCenter = rand(K, 3);
prevCluster = zeros(size(reshapeImg,1), 1);
currCluster = updateAssignments(reshapeImg, currCenter);

for i = 1:maxIteration
    currCenter = updateCenters(reshapeImg, currCluster, K);
    currCluster = updateAssignments(reshapeImg, currCenter);
    if(sum(currCluster ~= prevCluster) == 0)
        break;
    end
    prevCluster = currCluster;
end

labels = reshape(currCluster, size(data, 1), size(data,2));
centers = currCenter;

end

