%% CSC 262 Lab: Segmentation
%
% CSC 262

%% Overviews
% In this lab, we will implement segmentation using k-means. We will start
% by finding the cluster centers and updating each cluster by using the
% k-means algorithms to realize several functions for segmentation. In the
% end, we find that increasing the number of clusters gives a good result
% of segmentation but still suffers from some avoidable false positive
% segmentation.

%% Pixels To Clusters Assignment

%%
% Segmentation is an important image processing technique. We partition the
% image into multiple segments, which could be used for recognition or
% other purposes later. There are some properties of representation of
% objects in an image we could use to help us partition them into different
% segments. For example, most natural objects are composed of only a few
% colors. Then it is reasonable to assume that pixel clusters with the same
% color are likely representations of the same object. Under this
% assumption, we introduce the K-means Clustering. The idea is simple: We
% first assign each pixel into a cluster based on its distance with the
% cluster color (for example, the mean color of the pixels in the cluster,
% we will call it the cluster center). We then calculate the cluster
% centers for these new clusters. We will repeat these two steps until the
% segmentation doesn’t change any more. We will use the image below as the
% experiment image for this lab.

img = im2double(imread('/home/weinman/courses/CSC262/images/superior.jpg'));
downImg = imresize(img, 0.05, 'bicubic');
figure;
imshow(img);
title('Original Image');
pause(0.1);

rng('default');
rng(42);
K = 4;

reshapeImg = reshape(downImg, [], 3);
clusterCenter = rand(K, 3);

%%
% As one might notice in the algorithm described before: we need some
% clusters to begin with. Randomly assigning each pixel into some clusters
% might work, but we will need a lot more iterations for the algorithm to
% obtain the expected result. Consider a group of similar colors, their
% distance to some arbitrary cluster center will be close as well. We can
% just pick random cluster centers for the first iteration of cluster
% assignments, and we know pixels with similar colors will be assigned to
% the same cluster. We are not guaranteed that if two pixels are assigned
% to the same cluster, they will be the same color. But this should give us
% a good start. The palette below shows four randomly generated cluster
% centers.

image(1:K);
colormap(clusterCenter);
axis off;
title('Palette of 4 cluster centers');
pause(0.1);

%%
% From the palette, we expect the pixels representing the sky and the cloud
% to be assigned to the cluster with the color sky-blue as its center.
% However, the other three colors are not similar to anything in the image.
% But we can still make some predictions: green is a cool color, and we
% have two cool color cluster centers in the palette. The color of the
% trees appears to be dark green, so the pixels are likely to be assigned
% to the purple cluster. The beach is brown, which is somewhere between
% purple and crimson. Thus we cannot be sure about the color assignment.

%% Caculating new Cluster Centers
% Now we have the cluster centers, and segmentation can be done easily. We
% simply define the “distance” of pixels to be the sum of absolute values
% of their differences between each color channel. We calculate the
% distances for each pixel to all cluster centers and assign each of them
% to the cluster with the shortest distance. The initial assignment is
% shown below:

clusters = updateAssignments(reshapeImg, clusterCenter);
clusterImg = reshape(clusters, size(downImg, 1), size(downImg, 2));
figure;
imshow(clusterImg, clusterCenter);
title('Intial Cluster Assignment Image');
pause(0.1);

%%
% Notice the sky in the image is blue, as we should expect, but the tree
% and the beach are both assigned to the purple cluster. The color of the
% cluster image does not look like the original. We are just choosing
% arbitrary cluster centers for the first iteration, so this is expected.
% The image is recognizable, though. As we argued before, pixels with the
% same color should be assigned to the same cluster, even if the cluster
% centers were chosen randomly. Most cluster assignments are exactly as we
% expected, except the beach also has regions being assigned to sky-blue.
% But as we revisited the original image, we realized this result was not
% surprising. Notice there are a few outliers at the bottom of the beach
% and the upper right corner of the trees being assigned to crimson and
% pink. This is expected as we did not smooth the original image and our
% calculation of distance takes absolute values.

%%
% Once we have the new cluster assignments, calculating the center is easy:
% we simply take the mean of all pixels assigned to that cluster. And if
% there are clusters that haven’t been assigned with any pixels, we will
% pick new random centers for them, which is not the case with our initial
% centers.

newCenters = updateCenters(reshapeImg, clusters, K);
figure;
imshow(clusterImg, newCenters);
title('Updated Cluster Centers Image');
pause(0.1)

%%
% First thing to notice is the updated image only changed in color, as we
% are just recalculating the centers. Now notice the sky looks grayer than
% the original image. That gray is coming from the rocks on the beach,
% which has been assigned to the same cluster as the sky. The beach and the
% tree are yellowish green, which looks like what we get when we mix green
% with yellow/brown, so it is not surprising. Now the updated image is
% closer to the original image, but how should we proceed? The interesting
% part is the two regions of outliers we described before: now, the
% outliers that were at the bottom of the beach actually have the center
% with the color of the beach. And the outliers at the right corner of the
% trees are now assigned to a cluster with a dark green center. We should
% expect in the next iteration the beach, and the tree will be separated
% into two clusters, namely these two clusters with the two groups of
% outliers. What if we don’t have outliers? Recall we said if there are
% some clusters with no pixels, we assign random colors for them. This
% randomly generated cluster center either makes no progress, in which we
% will generate another random color, or some pixels are assigned to this
% cluster, which means we’ve made some progress toward an optimal
% assignment.

downImgG = gpuArray(downImg);
[clusters, map] = imkmeans(downImgG, K);

%% Segmentation Algorithm Evaluation
Kvals = [3 5 7 10];
centers = cell(size(Kvals, 2), 1);

%%
% The images below are generated by using different K values. K is the
% number of cluster groups. Therefore, as one might expect, the more
% clusters we have, the closer it will be for a group to have the right
% representation based on the k-means, and the richer the artifacts within
% the image will be. The images generated correspond to our expectations.
% When K = 3 and 5, although most of the artifacts are clustered in a
% reasonable group and are represented by a reasonable color, there are
% some false positives around the edge of the tree that are clustered in
% the beach group instead of the tree group. 

figure;
for i = 1 : size(Kvals, 2)
    
    [clusters, map] = imkmeans(downImgG, Kvals(i));
    segmentations(:,:,i) = clusters;
    centers{i} = map;
    subplot(2,2,i), imshow(clusters, map);
    title(strcat('Segmentation with K = ',int2str(Kvals(i))));
    pause(0.1);
    
end

%%
% As K increases, the representation is getting richer. For example, within
% the beach group, not only the general color of the stone beach is
% represented by yellow pixels, but some of the shadows in between the
% stones are also represented by black pixels. Besides, the sky cluster has
% an even more obvious effect. When K = 10, even the cloud is represented
% by shallow blue areas. Also, as the number of clusters increases, the
% false positives around the tree are weakened and corrected to an
% appropriate amount. However, since the cluster number is more than they
% actually need, the extra cluster also creates some false positives within
% the sky cluster. For example, to the tree's right, there is no cloud
% within that area. However, there are still some shadow blue, the cloud
% cluster, assigned to that region.

%% Different Clusters Observation

%%
% Then, we want to evaluate the segmentation result cluster by cluster.

%%
% In general, the clustering result for sky and tree works well when the
% number of clusters is three. These clusters are areas where the pixels
% are distinct from other pixel values. For example, sky areas are filled
% with blue pixels, and trees are filled with ‘green’ pixels. Therefore,
% when taking the average within the clusters, they still keep the same
% value. 

figure, imshow( (segmentations(:,:,1)==3)+1 , [ 0 0 0 ; centers{1}(3,:) ] );
title('Beach Cluster Image');
pause(0.1);

figure, imshow( (segmentations(:,:,1)==2)+1 , [ 0 0 0 ; centers{1}(2,:) ] );
title('Tree Cluster Image');
pause(0.1);

figure, imshow( (segmentations(:,:,1)==1)+1 , [ 0 0 0 ; centers{1}(1,:) ] );
title('Sky Cluster Image');
pause(0.1);

%%
% However, there are some false positives at the edges around the tree in
% the beach cluster that should not be clustered in the beach cluster. This
% might be due to the case where at the edge of the tree, the transition
% areas between the sky’s blue pixels and the tree’s green pixels are
% closer to the value of the average of the beach cluster. This explanation
% makes sense because when taking the average of the beach cluster at K =
% 3, the average pixel values are closer to gray instead of yellow. This
% artifact improves when K increases to 5 and more since the algorithms now
% could find more representations, and at the same time, the edge of the
% tree false positive issue is only weakened but not eliminated.

%%
% Therefore, to solve such an issue, we could think of two ways of
% improving the cluster algorithms: adding a weight matrix based on the
% distance between two pixels to avoid false positives or using median
% instead of mean to eliminate outliers. Adding a weight matrix should work
% because pixel values are clustered not only by the k-mean between two
% pixels but also determined by the distance between the two. If two pixels
% are closer, they have a higher probability of being in the same cluster
% group. Besides, this weight matrix is also robust because even if two
% same artifacts, say two trees at a large distance, are grouped in
% different clusters, and then when we classify them, they should still be
% in the same classification group (tree group). This way is still better
% than the false positive case that couldn’t distinguish the artifacts
% within the same cluster group.

%%
% Another approach, using the median instead of the average, works because
% the average considers the impact from outliers while the median is
% generally robust to these outliers. For example, in the beach clusters,
% most of the pixels within that cluster should be yellow. However, the
% average value gives a representation of gray due to the outliers coming
% from the dark shadows by the grain of sand. If we use the median
% approach, the beach approach should be closer to yellow, and therefore
% false positive around the tree should be gone. 

%% Conclusion
% In this lab, we use the k-mean algorithms to find an image's clusters to
% achieve the segmentation goal. We find that increasing the number of
% clusters gives a richer representation of the image, but it also suffers
% from the false positive representation from similar pixel values. In
% order to fix these errors, we proposed two ways, including adding a
% weight matrix based on the distance and using the median value instead of
% the mean to represent a cluster.

%% Acknowledgement
% The corresponding code is provided by professor Weinman in CSC-262
% Segmentation Lab.
% The 'superior.jpg' Image was taken by professor Weinman at Grand Marais,
% MN. Copyright 2006, licensed under a Creative Commons
% Attribution-Noncommercial-Share Alike 3.0 United States License.