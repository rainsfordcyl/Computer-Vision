function labels = updateAssignments(data,centers)
%	UPDATEASSIGNMENTS assign each data point into the cluster with shortest
%	color distance to its cluster center
%
%   DATA is a NM * 3 matrix shaped from an N*M*3 image. Centers is a K * 3
%   matrix, K is the number of clusters, and each chanel represents
%   corresponding RBG value with range [0 1]. LABELS is a NM * 1 matrix,
%   each entry is the cluster assignment of corresponding point with range
%   [1 K].

% Find the number of clusters
K = size(centers, 1);

% Initialize cluster assignment
cluster = zeros(size(data, 1), 1);
% Initialize distance of INF so all possible distances are smaller than
% initialization
distance = Inf(size(data, 1), 1);

% Looping over each cluster, update the cluster assignment if the distance
% from the point to the new cluster center is smaller than the distance to
% the center of the cluster assigned before
for i = 1:K
    % Calculate the sum and squared distance between the ith cluster center
    % and each datapoints.
    diff = data - centers(i,:);
    sumAndSquare = sum(diff.^2, 2);
    
    % Find the index in the dataponits that need to be updated to a new
    % cluster
    index = sumAndSquare < distance;
    % Assign the new cluster number
    cluster(index) = i;
    % Assign the new distance
    distance(index) = sumAndSquare(index);
end
% return the cluster assignment
labels = cluster;

end

