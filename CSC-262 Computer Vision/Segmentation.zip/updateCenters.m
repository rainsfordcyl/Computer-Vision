function centers = updateCenters(data,labels,K)
%UPDATECENTERS calculate the average pixel colors based on the cluster set.
%
%   DATA is the NM * 3 matrix reshaped from a N * M * 3 image
%   LABELS is the cluster assignment
%   K is the the number of clusters
%
%   CENTERS is a K by 3 matrix that returns each row consists of the
%   corresponding average color for that cluster set. If no pixles are
%   assigned to a corresponding cluster set, then a random color would be
%   picked.

% Generate a random center of number of clusters by 3
centers = rand(K,3);
% Loop through each the number of clusters
for i = 1:K
   % get the index of labels within the same cluster set
   index = (labels == i);
   % if no such labels are found, then we loop through the next cluster 
   if (sum(index(:)) == 0)
       continue;
   end
   % calculate the average color within that cluster set, and assign the
   % same cluster set with that average color.
   centers(i,:) = mean(data(index, :),1);
end


end

