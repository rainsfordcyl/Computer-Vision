%% CSC 262 Lab: Stereo Disparity
%
% CSC 262

%% Overview
% In this lab, we will estimate the depth using stereo disparity calculated
% by the minimum sum of squared differences (SSD) of an image pair. We find
% the optimal disparity by adjusting the parameters of different noise
% reduction methods. In the end, we find that the optimal disparity is
% derived using the Gaussian convolution of a kernel size of 12, better
% than the LoG pyramid and minimum SSD method.

% A
img1 = rgb2gray(im2double(imread('/home/weinman/courses/CSC262/images/view1.png')));
img5 = rgb2gray(im2double(imread('/home/weinman/courses/CSC262/images/view5.png')));
GroundTruthDisparity = double(imread('/home/weinman/courses/CSC262/images/truedisp.png'))/3;

% Convert all zeros in the GroundTruthDisparity to NaN
GroundTruthDisparity(GroundTruthDisparity==0) = NaN;
% Citation: https://www.mathworks.com/matlabcentral/answers/396120-in-a-matrix-how-to-replace-zero-by-nan

% Add largest disparity values of columns to both end of the images
paddedImg1 = padarray(img1,[0 max(GroundTruthDisparity(:))], 0, 'post');
paddedImg5 = padarray(img5,[0 max(GroundTruthDisparity(:))], 0, 'post');

% Shift view 5 by 50 pixels horizontally
shiftedImg5 = imtrans(paddedImg5, 0, -50, 0);
% Citation: imtrans is introduced by Professor Weinman in his lecture

% Calculate the squared difference of the two images
squaredDiffImg = (shiftedImg5 - paddedImg1).^2;
%imshow(squaredDiffImg);

% Convolution using 5*5 window over the squared differences image.
kernel = ones(1,5);
sumSquaredDiff = conv2(kernel, kernel',squaredDiffImg, 'same');

% B
maxDisparity = max(max(GroundTruthDisparity));
StackSSD = zeros(size(sumSquaredDiff,1),size(sumSquaredDiff,2), maxDisparity);

for i=maxDisparity:-1:1
    shiftedImgLoop = imtrans(paddedImg5, 0, -i, 0);
    squaredDiff = (shiftedImgLoop - paddedImg1).^2;
    kernel = ones(1,5);
    SSD = conv2(kernel, kernel',squaredDiff, 'same');
    StackSSD(:,:,i) = SSD;
end



% C
[C, I] = min(StackSSD(:,1:size(GroundTruthDisparity, 2),:), [], 3);

k = isnan(GroundTruthDisparity);

%predictedRMS = sqrt(mean(C(:).^2, 'omitnan'));

%actualRMS = sqrt(mean(GroundTruthDisparity(:).^2, 'omitnan'));

RMS = sqrt(mean((GroundTruthDisparity(:) - I(:)).^2,'omitnan'));

%% Finding the Optimal Disparity
% After we had gotten our initial results of our RMS using a 5x5 SSD
% window, we decided to test for smaller and larger SSD windows. We tested
% on windows of size 2,3,5,10, and 20, respectively. The window size versus
% the RMSE plot showcases a parabolic pattern with smaller SSD window sizes
% of 2 and 3 having larger values of RMSE. The same can also be said for
% window sizes 10 and 20. That means the optimal window size for the
% smallest RMSE was between 5 and 10. We tested out 7 as a result and got
% the smallest RMSE value out of all window sizes tested. If the window is
% too small, you risk getting affected by outlier spikes in the image,
% resulting in larger errors. This is magnified quadratically, given the
% computation of RMSE. On the other hand, with a large window, you risk
% computing contrasting regions to each other, especially in regions where
% there's a difference in the objects' 3D positions. The disparities would
% be more pronounced there, and with larger SSD windows, you might compute
% the RMSE of two regions in the same pixel, resulting in higher error
% values. The window size of 7 was then shown to be the most optimal
% choice, as seen in the comparison plot, which we would use for future
% reconstruction.

for i=maxDisparity:-1:1
    shiftedImgLoop = imtrans(paddedImg5, 0, -i, 0);
    squaredDiff = (shiftedImgLoop - paddedImg1).^2;
    kernel = ones(1,7);
    SSD = conv2(kernel, kernel',squaredDiff, 'same');
    StackSSD(:,:,i) = SSD;
end

[C, I] = min(StackSSD(:,1:size(GroundTruthDisparity, 2),:), [], 3);

k = isnan(GroundTruthDisparity);
% RMS for a kernel size of 5
% RMS5 = sqrt(mean((GroundTruthDisparity(:) - I(:)).^2, 'omitnan'));
RMS7 = sqrt(mean((GroundTruthDisparity(:) - I(:)).^2, 'omitnan'));
% RMS10 = sqrt(mean((GroundTruthDisparity(:) - I(:)).^2, 'omitnan'));
% RMS2 = sqrt(mean((GroundTruthDisparity(:) - I(:)).^2, 'omitnan'));
% RMS3 = sqrt(mean((GroundTruthDisparity(:) - I(:)).^2, 'omitnan'));
% RMS20 = sqrt(mean((GroundTruthDisparity(:) - I(:)).^2, 'omitnan'));

% plotRMS = [RMS2, RMS3, RMS5, RMS7, RMS10, RMS20];
% plotSize = [2,3,5,7,10,20];
% save('RMSplot.mat','plotRMS','plotSize');

load('RMSplot.mat');

pause(0.05);
figure;
plot(plotSize, plotRMS);
title('kernel size VS RMS Trade-Offs');
xlabel('kernel size');
ylabel('RMS');
pause(0.05);
%%
% After we had gotten our initial results of our RMS using a 5x5 SSD
% window, we decided to test for smaller and larger SSD windows. We tested
% on windows of size 2,3,5,10, and 20, respectively. The window size versus
% the RMSE plot showcases a parabolic pattern with smaller SSD window sizes
% of 2 and 3 having larger values of RMSE. The same can also be said for
% window sizes 10 and 20. That means the optimal window size for the
% smallest RMSE was between 5 and 10. We tested out 7 as a result and got
% the smallest RMSE value out of all window sizes tested. If the window is
% too small, you risk getting affected by outlier spikes in the image,
% resulting in larger errors. This is magnified quadratically, given the
% computation of RMSE. On the other hand, with a large window, you risk
% computing contrasting regions to each other, especially in regions where
% there's a difference in the objects' 3D positions. The disparities would
% be more pronounced there, and with larger SSD windows, you might compute
% the RMSE of two regions in the same pixel, resulting in higher error
% values. The window size of 7 was then shown to be the most optimal
% choice, as seen in the comparison plot, which we would use for future
% reconstruction.



%% 2-D Disparity Reconstruction
% Overall, the hypothesized disparity doesn't have an even mapping surface.
% This effect is very obvious on the artifacts' surfaces, such as the head,
% hollow disks, cylinder, etc. The only place where it's even is on the
% left side of the image, where the original true disparity also couldn't
% distinguish any disparity. 

figure;
surf(GroundTruthDisparity, 'EdgeColor','none');
axis ij;
title('True Disparity Plot');
pause(0.5);

pause(0.5);
figure;
surf(I, 'EdgeColor','none');
axis ij;
title('Predicted Disparity Plot');
pause(0.5);

pause(0.5);
figure;
imshow(GroundTruthDisparity,[]);
colormap jet;
title('2D True Disparity Colourful Visualization');
pause(0.5);

% The code for saving the figure with the colormap included is found here:
% https://www.mathworks.com/matlabcentral/answers/155342-how-to-save-the-content-of-the-current-figure-as-an-image
pause(0.5);
Inoise = I;
I(k) = NaN;
figure;
imshow(I,[]);
colormap jet;
title('2D Hypothesized Disparity Colourful Visualization');
saveas(gcf,'HypothesizedDisparity.png');
pause(0.5);
%%
% Besides the uneven surface, another global effect is that the overall
% disparity is more drastic than before. For example, the head's disparity
% in the true image is light blue; however, the same structure's disparity
% in the hypothesized is yellow, with a darkened blue around the back of
% the head. Also, there are noticeable uneven red patches on the surface of
% the yellow head, corresponding to the observation we made above.

%%
% In addition, there exist several values that seem to mesh together. The
% hollow circles are not accurately represented in the hypothesized
% disparity image. In the original true disparity image, the hollow circles
% are evenly separated. However, in the hypothesized disparity, the
% overlapped hollow circles are ignored. Other hollow circles around the
% edge of the back artifacts are represented by a dark rectangle from the
% separable filter of the Gaussian kernel instead of a dark blue circle.


%% Noise-reduction method on Disparity
% While previously, we have only reconstructed the disparity image after
% changing all zero values into NaN, this will not be appropriate when we
% are trying to reduce the noise for the disparity. This is because we will
% smear out large sections of the image when we apply our smoothing filter
% if we do convert them into NaN. This will result in a large loss of
% properties for smooth reconstruction. For the methods themselves, we
% tested two noise-reduction methods: the Gaussian kernel and the Laplacian
% of Gaussian (LoG) pyramid. For the Gaussian kernel method, we create a
% 1-D Gaussian kernel with a variance of 5 and then apply it as a separable
% filter to create a 2-D Gaussian kernel on the predicted disparity image.
% For the Laplacian pyramid method,

%%
% Besides using the Gaussian kernel of different invariance, we also
% incorporate the method of Laplacian of Gaussian pyramid method with a
% height of two. We use the same approach as implemented in the pyramids
% and wavelets lab. We first build a pyramid of height two using the
% disparity image. Then, we first use the low-pass bands filter derived
% from the last few entries in the pyramid vector. This smoothens the image
% and then uses the high-pass bands to get a lower-level image of a smaller
% size. Then, we compress the image by "zero out" values sufficiently close
% to zero, discarding 80% of our coefficients. We only get to the second
% level to avoid the performance issue. After recovering the images back,
% this method gives us a promising RMSE of 9.3, which is still better than
% most of the SSD methods with different window sizes.

% Gaussian
% Gaussian kernel with a invariance of 5
% The code for saving the figure with the colormap included is found here:
% https://www.mathworks.com/matlabcentral/answers/155342-how-to-save-the-content-of-the-current-figure-as-an-image
g = gkern(12);
Ireduce = conv2(g,g', Inoise, 'same');
figure;
imshow(Ireduce,[]);
colormap jet;
title('Post-processed Disparity Map using Gaussian Convolution');
saveas(gcf,'BestPostProcessedDisparity.png');
pause(0.5);

%%
% The RMSE of the disparity using the Gaussian filter of variance 12 is as follows:
RMSGaussian = sqrt(mean((GroundTruthDisparity(:) - Ireduce(:)).^2, 'omitnan'))

% RMSInvariance = [1,3,7,12,13,15];
% RMSGaussianVec = [RMSGaussian1,RMSGaussian3,RMSGaussian7,RMSGaussian12,RMSGaussian13,RMSGaussian15];
% save('RMSInvariance.mat','RMSInvariance','RMSGaussianVec');
load('RMSInvariance.mat');

% Laplacian Pyramid
% Citation: Previous PyramidAndWavelets lab (Detailed citation with name is
% in the acknowledgement part);

[pyrValues, pyrDims] = buildLpyr(Inoise, 2);
boundary = unique(pyrDims(:, 1));
boundary = boundary(2:end);
boundary = sum(boundary.^2);
highBand = pyrValues(1:boundary);
lowBand = pyrValues((boundary+1): end);
sortedHighBand = sort(abs(highBand));
threshold = sortedHighBand(round(length(sortedHighBand)*0.8));
highBand(highBand<threshold) = 0;
sparseHighband = sparse(highBand);
concatVec = [highBand; lowBand];
ILoG = reconLpyr(concatVec, pyrDims);
pause(0.05);
%%
% The RMSE of the disparity using the LoG pyramid is as follows:
RMSLoG = sqrt(mean((GroundTruthDisparity(:) - ILoG(:)).^2, 'omitnan'))

figure;
imshow(ILoG, []);
title('Post-processed Disparity Map using Laplacian Pyramid');
colormap jet;


%%
% Looking at the result disparity image, since we zero out some of the
% values; therefore the recovered image's dark blue 'patches' are shaper
% than the gaussian convolution of invariance of 12. On the one hand, the
% shaper edge distinguishes the background and the 3-D artifacts better. On
% the other hand, however, it also gives some errors in distinguishing some
% noisy parts of the image. For instance, the three paint pens and the
% background artifacts intersect at the center of the image. This
% intersection is represented by some random rectangles and diamond-shaped
% red significant disparities, producing a false representation.


pause(0.05);
figure;
plot(RMSInvariance,RMSGaussianVec);
title('Gaussian Convolution with different invariance to reduce RMS');
xlabel('Variance Size');
ylabel('Corresponding RMS');
pause(0.05);

%%
% We decided to experiment with the Gaussian filter method's parameters to
% test the method's effectiveness under different variances. As the
% variance increases from 0 to around 12, we see that the RMSE values saw a
% decrease. However, after a variance of 12, higher variances result in
% worse RMSE. This can be attributed to the loss of details and contrast
% compared to the true disparity as the box filter's size becomes too
% large. We then decided to use a Gaussian kernel of variance 12 for the
% best post-processed reconstruction.

%%
% Compared to the original reconstruction, we can see that much of the
% noise has been removed from the post-processed version using the Gaussian
% filter. The main properties of the disparity image are also largely
% preserved. This is especially true for the statue head's region, where
% the disparity in the original version is filled with a lot of noise. In
% the post-processed result, the region is largely homogenized to have
% relatively similar values as in the true disparity version. However, it
% is not a strict improvement compared to the original version. The
% original predicted disparity image is a lot easier to determine the main
% 3-D structure of the image as it is clearly outlined despite the
% prevalence of noise. The post-processed version has removed this noise
% but in exchange for a loss in details, especially for small and thin
% objects like the paint brushes. They are now mostly just smears in the
% post-processed reconstruction instead of having a clear outline like in
% the original version. Also, since the original reconstruction excluded
% all occluded points, the loss in details is even more apparent as the
% post-processed version includes all possible points, even ones that
% cannot be reconstructed. However, if we simply consider the overall
% structure instead of exact details, the post-processed disparity image
% has largely managed to retain all of the key details of the disparity
% seen in both the predicted and actual values.

%% Conclusion
% To estimate the depth of objects in an image pair, we find the stereo
% disparity by calculating the minimum SSD of different methods. Methods
% used include adjusting SSD window size, Gaussian convolution with
% different invariance, and LoG pyramid. We find the optimal stereo
% disparity with a Gaussian convolution with an invariance size of 12, with
% minimal trade-offs of edge boundaries. The result suggests a lesson that
% Gaussian convolution is the best method to find the stereo disparity of
% an image pair since it has the least RMS without significant trade-offs
% in the quality of the reconstructed image.

%% Acknowledgement
% The command imtranslate is provided by Jerod Weinman in the lab The
% images are provided in the 2005 Middlebury stereo dataset
% (https://vision.middlebury.edu/stereo/data/scenes2005/) Christopher J.
% Pal, Jerod J. Weinman, Lam C. Tran and Daniel Scharstein. (2012). On
% Learning Conditional Random Fields for Stereo: Exploring Model Structures
% and Approximate Inference. International Journal of Computer Vision,
% 99(3), 319-337. 
% The Laplacian Pyramid implementation is from Rainsford L.
% and Will C. in the Image filtering lab's script.