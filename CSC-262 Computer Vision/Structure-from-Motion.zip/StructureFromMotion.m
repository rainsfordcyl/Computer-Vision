%% CSC 262 lab: Structure from Motion
%
% CSC 262

%% Overview
% Given synthetic images at different angles, we will use a given set of 
% very dense feature matches to create a 3-D orthographic reconstruction. 
% We will also manually adjust the amount of sparsity and noise added to 
% the image. We found that sparsity impacts the generated structure more 
% than noise.

%% Preparations
% We will start this process by finding the feature points in the images. 
% Using the mesh grid function, we construct a 2-D spatial domain of the 
% pixels of the image in the frame1. Then, the corresponding coordinates of
% each pixel's coordination transformation, provided by professor Weinman, 
% are added to the coordinates in the image in frame 1 to get the coordinates
% of the image in frame 2. We put these four 1-by-N matrices together to form
% a 4-by-N matrix. The x coordinates from the first image are the first row,
% the x coordinates of the matching points from the second image are the second
% row, the y coordinates of the first image are the third row, and the y 
% coordinates of the second image are the last row.
%
% To conveniently analyze the feature points detected, we subtract the mean
% of each row by each element in that row to move these points to the 
% center. Then, we apply the singular value decomposition (SVD) to the 
% processed matrix above. Notice that we want a three-dimensional 
% construction (matrix rank of 3), so the fourth row of coordinates will 
% not be used. Since SVD is a math process and we think as a mathematician,
% we will call these resulting SVD matrices U, W, and V. W is the 3-by-3
% singular matrix we wanted. 

img = im2double(imread('/home/weinman/courses/CSC262/images/frame1.png'));
load /home/weinman/courses/CSC262/images/flow.mat   % For frame1.png

% Get the number of rows of image in Frame1
Frame1row = 1:size(img, 1);
% Get the number of column of image in Frame2
Frame1col = 1:size(img, 2);
% Create a meshgrid of the two images
[imgFrame1X, imgFrame1Y] = meshgrid(Frame1col,Frame1row);

% Calculate the ?
imgFrame2X = imgFrame1X + F(:, :, 1);
imgFrame2Y = imgFrame1Y + F(:, :, 2);

% Get the x coordinate of the image in Frame 1
img1Xcoord = imgFrame1X(:);
% Get the corresponding x coordinate of the image in Frame 2
img1XcoordMatch = imgFrame2X(:);
% Get the y coordinate of the image in Frame 1
img1Ycoord = imgFrame1Y(:);
% Get the corresponding y coordinate of the image in Frame 2
img1YcoordMatch = imgFrame2Y(:);

TwoFramePoints = [img1Xcoord'; img1XcoordMatch'; img1Ycoord'; img1YcoordMatch'];
TwoFramePointsMean = [mean(img1Xcoord); mean(img1XcoordMatch); mean(img1Ycoord); mean(img1YcoordMatch)];
BalancedTwoFramePoints = TwoFramePoints - TwoFramePointsMean;
%% The factorization
% The top three singular values from decomposition are 2468.97625297322, 
% 1629.66933629824, and 15.4250511092934 separately. Notice that the first 
% two values are large compared with the third value. This makes sense 
% because we are only given the images at two frames, providing less 
% information on the z-axis (depth) compared with the first two dimensions 
% x-axis and y-axis (length and width). These differences will also be 
% reflected more in the later reconstruction model part. 

[U,W,V] = svd(BalancedTwoFramePoints,'econ');
% Citation: function provided by Profeesor Weinman in https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/structure-from-motion.html
SingularMatrix = W(1:3,1:3);

V3 = V(1:(size(V,1)),1:3);
% Scale the x y z to the right amount 
% x and y scale a lot but z scale not so much by looking at the range of
% the 3d space.

%%
% By taking the production of W and V, we get the S* which is another 
% mathematically meaningful value. This S* will be useful and handy for 3-D
% restoration in this part. We construct the 3-D structure by calling the
% Matlab built-in function Delaunay. 

Sstar = SingularMatrix * V3';

%% Reconstruction
T = delaunay(Sstar(1,:),Sstar(2,:));
figure;
trisurf(T,Sstar(1,:),Sstar(2,:),Sstar(3,:), 'EdgeColor', 'none', 'FaceColor','red');
title('3D Structure recovered');
lighting phong
view([-161 46]);
camlight headlight
% Citation: these functions are provided by Profeesor Weinman in https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/structure-from-motion.html

%%
% The structure looks as we would expect from the front (the same 
% perspective that the original images were taken from). All of the
% building geometry is visible. However, when rotating the view to look at
% the bottom of the structure, there are 3D structures that appear that we
% don’t expect. There are flat planes under some of the building structures
% from the bottom. These aren’t expected because no such structures exist 
% in the original images. The square holes in the tops of the building also
% look triangular from the bottom, which is also unexpected. Finally, the 
% surfaces of the buildings are rough in a way that is unexpected because 
% the roughness isn’t consistent with the texture of the buildings in the 
% original images, rather the surface is equally rough all over. This might
% be due to the float number being limited by the 32-bit number of the 
% given image, so there are some tiny variations in its coordinates.
%
% Besides, when rotating to its side, it seems like the structure is 
% unstable and varies its shape drastically given a slight rotation. The
% edge of the structure seems to have a trend to converge together. As we
% explained in the singular value part, this might be due to the lack of 
% depth information, causing the image to transform knowing less about the
% z-axis and being not robust.


%% Adding color
% Attaching red color to the surface is less satisfactory since the given 
% image is colored. Therefore, we want to attach the original RGB value to 
% the 3-D structure we just made. We will attach surface color by index.
%
% We first convert the original image to give indices to the image using 
% 256 colors. Then, we use the built-in Matlab command to index the image 
% with 256 colors using the colormap we just created. This gives the 3-D 
% structure the original RGB value, and the result is shown above.

rgbImg = imread('/home/weinman/courses/CSC262/images/frame1.png');
Frame1col = 1:size(img, 2);
% Create a meshgrid of the two images
[imgFrame1X, imgFrame1Y] = meshgrid(Frame1col,Frame1row);

% Index Image converst the image to a color coded index arrays
% colorMap stores the corresponding rgb value of an index
[indexImg,colorMap] = rgb2ind(rgbImg, 256);
reshapeVector = reshape(indexImg,[],1);

figure;
trisurf(T,Sstar(1,:),Sstar(2,:),Sstar(3,:),reshapeVector, 'EdgeColor', 'none');
title('3D Structure recovered in RGB ([0 90] view)');
colormap(colorMap);
view([0, 90]);
snapnow;

figure;
trisurf(T,Sstar(1,:),Sstar(2,:),Sstar(3,:),reshapeVector, 'EdgeColor', 'none');
title('3D Structure recovered in RGB ([10 60] view)');
colormap(colorMap);
view([10, 60]);
snapnow;

%%
% First, in the [0 90] view, the structure is very similar to the original 
% image. However, we aren’t sure if it is because of the monitor setting, 
% the 3-D structure image has a darker surface than the original image. 
% Also, tiny and shining white dots are distributed on the structure's 
% surface. This might also be due to the cam light headlight effect. But 
% looking at the generated structure, a similar trend happens with the 
% previous red surface 3-D structure.
%
% Second, looking at the side of the structure, strangely, the structure 
% has a trend to converge. Also, as we explained before, the singular value
% in the third dimension is less than the first two dimensions, therefore, 
% when we force the structure to generate information in the depth 
% dimension, we can only find the correct but odd structure. 
%
% Thirdly, looking at the back of the structure, the surface also is 
% attached to the RGB value of the original image. This is very confusing
% because the operation we had above aims to attach color to the surface in
% the front. This might be explained by the algorithm of Matlab’s command 
% colormap and trisurf.

%% Sparcity and noise

% randomly pick an index within the img1
randomNum = 60000;
indexRange = size(img1Xcoord,1);
randIndex = randi(indexRange,1,randomNum);

% Get random index of x coordinate of the image in Frame 1
randImg1Xcoord = imgFrame1X(randIndex);
% Get the corresponding random x coordinate of the image in Frame 2
randImg1XcoordMatch = imgFrame2X(randIndex);
% Get random index of y coordinatn Frame2
Frame1col = 1:size(img, 2);
% Create a meshgrid of the two images
[imgFrame1X, imgFrame1Y] = meshgrid(Frame1col,Frame1row);

% Calculate the ?e of the image in Frame 1
randImg1Ycoord = imgFrame1Y(randIndex);
% Get the corresponding random y coordinate of the image in Frame 2
randImg1YcoordMatch = imgFrame2Y(randIndex);

noiseMultiplier = 1;

% add noise to each coordinate matrix
% randImg1Xcoord = randImg1Xcoord + (noiseMultiplier * randn(1,randomNum));
% randImg1XcoordMatch = randImg1XcoordMatch + (noiseMultiplier * randn(1,randomNum));
% randImg1Ycoord = randImg1Ycoord + (noiseMultiplier * randn(1,randomNum));
% randImg1YcoordMatch = randImg1YcoordMatch + (noiseMultiplier * randn(1,randomNum));

randPointsMatches = [randImg1Xcoord; randImg1XcoordMatch; randImg1Ycoord; randImg1YcoordMatch];
randPointsMatchesMean = [mean(randImg1Xcoord); mean(randImg1XcoordMatch); mean(randImg1Ycoord); mean(randImg1YcoordMatch)];
randPointsMatchesBalanced = randPointsMatches - randPointsMatchesMean;

noiseMatrix = 0.000001 * randn(4,randomNum);
randPointsMatchesBalanced = randPointsMatchesBalanced + noiseMatrix;

[U,W,V] = svd(randPointsMatchesBalanced,'econ');
SingularMatrix = W(1:3,1:3);

pause(0.03);

V3 = V(1:(size(V,1)),1:3);

Sstar = SingularMatrix * V3';
T = delaunay(Sstar(1,:),Sstar(2,:));
pause(0.03);
figure;
trisurf(T,Sstar(1,:),Sstar(2,:),Sstar(3,:), 'EdgeColor', 'none', 'FaceColor','red');
title('3D Structure recovered based on random coordinates');
lighting phong
view([10 80]);
camlight headlight;
pause(0.03);

figure;
[indexImg,colorMap] = rgb2ind(rgbImg, 256);
reshapeVector = reshape(indexImg(randIndex),[],1);
trisurf(T,Sstar(1,:),Sstar(2,:),Sstar(3,:),reshapeVector, 'EdgeColor', 'none');
title('3D Noisy Structure recovered in RGB');
view([10 80]);
colormap(colorMap);

%%
% We explore the relationship between the amount of sparsity, noise 
% injected, and the quality of the generated result. We found that sparsity
% has a global effect on the generated structure, while the amount of noise 
% injected has a local effect on the structure's surface rather than
% changing the general shape of the 3-D structure. 
%
% If we increase the amount of sparsity and keep the noise small, 
% collecting less sampling in the original image while keeping the amount 
% of noise small, the 3-D structure becomes less like the structure we 
% expected. Although the structure we expected is generally a rectangle, 
% we generated some oval structure by increasing the sparsity to less than 
% half of the original spot. Notice that since we keep the amount of noise 
% the same, the odd 3-D structure’s surface is still not smooth. Since we
% change the structure's global structure, we conclude the amount of
% sparsity has a larger impact on the structure.
%
% If we keep the amount of sparsity the same but increase the amount of 
% noise, we find that the structure's surface becomes very coarse and even 
% looks like a hedgehog building. A random amount of noise is added to the 
% local value of the 3-D structure. Since we kept the amount of sparsity 
% the same, we didn’t see a change in the global shape of the structure.
%
% The last experiment is to increase both noise and sparsity. This 
% structure is the oddest of all. Since the sparsity increase, collecting 
% fewer samples means the generated structure is not as expected. 
% Increasing the amount of noise means the structure's surface is uneven 
% locally. Therefore, we didn’t expect anyone to tell us what the generated
% structure is, and obviously, it’s not a building.


%% Conclusion
% We explored constructing a 3-D model given two images from two frames. We
% construct the image using feature matching, singular matrices, and singular
% value decomposition. Also, by manipulating the noise and sparsity of the
% given images, we found that since sparsity has a global effect on the 
% overall structure of the image compared to noise added locally, the 
% sparsity of the image has a larger impact on the structure of the 3-D 
% construction.

%% Acknowledgement
% The raw image is provided by MatLab.
%
% The Matlab markup guide: https://www.mathworks.com/help/matlab/matlab_prog/marking-up-matlab-comments-for-publishing.html
%
% Code is from the lab manual page: https://weinman.cs.grinnell.edu/courses/CSC262/2022F/labs/feature-matching.html