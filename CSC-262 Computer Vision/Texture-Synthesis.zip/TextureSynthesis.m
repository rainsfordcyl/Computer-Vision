%% CSC 262 Lab: Texture Synthesis
%
% CSC 262

%% Overviews
% We will synthesize the texture of a target texture image from a white
% noise image using the steerable pyramid and histogram equalization. We
% create a function including a loop that keeps running until the error
% difference between the synthesized image and the source is below a
% certain threshold. We use the function for several texture images and
% find that a threshold of 0.05 is the optimal balance between quality and
% efficiency.

%% Creating Noise Image and the First Histogram Equalization
% We start by importing the carpet image from the University of Oulu
% Texture Database. We use this image as our target which would be
% generated from white noise images of the same size. The target image and
% the noise image are shown below. 

% img = imread('/home/weinman/courses/CSC262/images/texture/carpet002-inca-100dpi-00.bmp');

img = rgb2gray(im2double(imread('/home/weinman/courses/CSC262/images/texture/carpet002-inca-100dpi-00.bmp')));

%%
bins = 256;
scales = 5;
orientation = 4;

binEdges = linspace(0,1,bins);

grayImg = zeros(size(img,1), size(img,2)) + 0.5;
noiseImg = imnoise(grayImg, 'gaussian');

figure;
imshow(img,[]);
title('Starting Image');
pause(0.1);

figure;
imshow(noiseImg,[]);
title('Starting Noise Image');
pause(0.1);

originalHistogram = histc(img(:), binEdges);

%%
% The method we will use is histogram equalization. We first plot the
% histogram of the target shown below. Notice that most of the pixels have
% a brightness value of around 55. Then, getting the result of the sample
% image histogram, we transform the input noise image to have the same
% histogram as the sample image by calling the histeq function. The result
% is shown below. 

figure;
bar(originalHistogram);
title('Histogram of the sample image');
xlabel('Pixel Brightness');
ylabel('Pixel Counts');
pause(0.1);

equalizedImg = histeq(noiseImg,originalHistogram);

figure;
imshow(equalizedImg, []);
pause(0.1);
title('Equalized Noise Image using sample histogram');
pause(0.1);

%%
% Notice that compared with the starting noise image, the equalized noise
% image is darker overall while still keeping the same texton, the
% generated Gaussian noise. This means the histogram of the starting noise
% image shifted to the left. But solely based on the histogram, we cannot
% build the target texture, suggesting that further operators need to be
% included. Besides, the starting image also has spatial gradient
% information, as the image is darker on the top and brighter on the
% bottom. However, the histogram equalization doesn’t include such
% information and couldn’t be reflected in the equalized image. 

%% Comparing Steerable Pyramid Bands Between Original and Synthesized Images
% The images below are examples for steerable pyramid band from the
% original image and the synthesized image. We will analyze these two with
% their corresponding histogram next.

 % create the steerable pyramid for the original image
 [steerPyrOriginal, OriginalImgindices] = buildSFpyr(img, scales);
 
 % create the steerable pyramid for the texture synthesis image
 [steerPyrSynthesized, SynthesizedImgindices] = buildSFpyr(equalizedImg, scales);

 bandNum = 2;
 
 pyrBandOriginal = pyrBand(steerPyrOriginal,...
     OriginalImgindices,...
     bandNum);
 pyrBandSynthesized = pyrBand(steerPyrSynthesized,...
     SynthesizedImgindices,...
     bandNum);

 figure;
 imshow(pyrBandOriginal, []);
 title('Steerable Pyramid Band From Original Image');
 pause(0.1);
 
 figure;
 imshow(pyrBandSynthesized, []);
 title('Steerable Pyramid Band From Synthesized Image');
 pause(0.1);
 
 %% 
 % The histogram of the laplacian pyramid band in the original image shows
 % that pixel values range from around 80 to 160 brightness levels out of
 % 256, whereas the histogram of the corresponding band in the white noise
 % pyramid has pixel values ranging from 0 to 256 brightness levels out of
 % 256. The shape of the original image band histogram is more narrow,
 % compared to the noise image band. Further, we see spikes in pixel counts
 % at brightness level 0 and brightness level 256 in the noise image band
 % histogram because we adjust the pixel brightness values to match the
 % range of brightnesses that the original image had. Pixels in the noise
 % image that was greater or smaller than the upper or lower bound of pixel
 % brightnesses in the original image band become set to the highest or
 % lowest pixel value in the original image, causing these spikes at 0 and
 % 256 in the noise histogram.
 
 bandMax = max(pyrBandOriginal(:));
 bandMin = min(pyrBandOriginal(:));
 
 
 pyrBandOriginalAdj = imadj(pyrBandOriginal,...
     [bandMin bandMax],...
     [0 1]); 
 
 pyrBandSynthesizedAdj = imadj(pyrBandSynthesized,...
     [bandMin bandMax],...
     [0 1]); 
 
 originalBandHistogram = histc(pyrBandOriginalAdj(:), binEdges);
 
 synthesizedBandHistogram = histc(pyrBandSynthesizedAdj(:), binEdges);
 
 figure;
 bar(originalBandHistogram);
 title('Histogram of band from original image');
 xlabel('Pixel Brightness');
 ylabel('Pixel Counts');
 pause(0.1);
 
 figure;
 bar(synthesizedBandHistogram);
 title('Histogram of band from synthesized image');
 xlabel('Pixel Brightness');
 ylabel('Pixel Counts');
 pause(0.1);
 
 adjustedSynthesizedImgBand = histeq(pyrBandSynthesized,originalBandHistogram);
 
 transformedSynthesizedImgBand = imadj(adjustedSynthesizedImgBand,...
     [0 1],...
     [min(pyrBandSynthesized(:)) max(pyrBandSynthesized(:))]); 
 
 %%
 % Comparing the images of steerable pyramid band index 2 in the original
 % image, the noise image, and the histogram equalized noise image, we can
 % see that the original image band and the noise image band appear
 % similar. This is to be expected since we histogram normalized the entire
 % noise image to look more like the original image initially. The noise
 % image band after histogram equalization with the respective original
 % image band appears darker than the first two images we showed above.
 % This is caused by the way the histogram equalization function maps
 % pixels and the display bounds when showing the image. When observing the
 % noise image band histogram after equalization, we saw that a majority of
 % pixels are mapped to a mid-range pixel value, then fewer pixels are
 % mapped to a higher mid-range value, and continually less and less pixels
 % are mapped to higher and higher values in the histogram. This results in
 % the image appearing dark because the lower bound of pixels (black
 % pixels) is the mid-range value, and this value has a majority of the
 % pixels in the image.
 
 figure;
 imshow(transformedSynthesizedImgBand, []);
 title('Transformed Image from Synthesized Band Image');
 pause(0.1);
 
 %% Adjusting Every Band in the Steerable Pyramid
 % After we equalize each band of the synthesized image based on the
 % corresponding band of the original image, we integrate them into a
 % single steerable pyramid and reconstruct the synthesized image. The
 % adjusted synthesized steerable pyramid is shown below. Notice that the
 % image is a lot like the original texture image. Overall, rather than
 % making the whole image darker like we simply did in the linear
 % equalization, we now have an equal amount of white and dark blobs in the
 % image. However, since we didn’t incorporate the spatial information in
 % each band from the histogram, the gradient information is not kept in
 % the adjusted image. However, since we used the steerable pyramid and
 % adjusted the noise image level by level, the artifacts within the image
 % are very similar. The carpet’s pothole structure is very obvious. 
  
 resultPyr = steerPyrSynthesized;
 
 for i=1:size(SynthesizedImgindices,1)
     pyrBandOriginal = pyrBand(steerPyrOriginal,...
         OriginalImgindices,...
         i);
     pyrBandSynthesized = pyrBand(steerPyrSynthesized,...
         SynthesizedImgindices,...
         i);
     
     bandMax = max(pyrBandOriginal(:));
     bandMin = min(pyrBandOriginal(:));
 
     pyrBandSynthesizedAdj = imadj(pyrBandSynthesized,...
        [bandMin bandMax],...
        [0 1]); 
    
     pyrBandOriginalAdj = imadj(pyrBandOriginal,...
        [bandMin bandMax],...
        [0 1]); 
    
     originalBandHistogram = histc(pyrBandOriginalAdj(:), binEdges);
 
     synthesizedBandHistogram = histc(pyrBandSynthesizedAdj(:), binEdges);
    
     adjustedSynthesizedImgBand = histeq(pyrBandSynthesizedAdj,originalBandHistogram);
 
     transformedSynthesizedImgBand = imadj(adjustedSynthesizedImgBand,...
        [0 1],...
        [bandMin bandMax]); 
     
    % get indices for the band to update
    bandIndex = pyrBandIndices(OriginalImgindices, i);
    
    resultPyr(bandIndex:(bandIndex + size(transformedSynthesizedImgBand(:), 1) - 1))...
        = transformedSynthesizedImgBand(:);
 end
 
 adjustedSynthesizedImg = reconSFpyr(resultPyr, OriginalImgindices);
 
 histEqualizedAdjustedSynthesizedImg = ...
     histeq(adjustedSynthesizedImg,originalHistogram);
 
 figure;
 imshow(histEqualizedAdjustedSynthesizedImg, []);
 title('Adjusted Synthesized Steerable Pyramid');
 pause(0.5);
 
 %%
 % However, zooming in on the image, the adjusted synthesized image
 % couldn’t keep the gradient information even at the lowest level. Notice
 % that for each pothole in the original image, the pothole are brighter on
 % the top and darker on the bottom, suggesting that the light comes from
 % the bottom to the carpet. However, looking at the synthesized image, the
 % pothole structure is messy and not unified. This suggests that the
 % histogram lacks information on where the light comes from and simply
 % constructs the brightness based on the histogram distribution in each
 % band.
 
 %% Observation of Texture Synthesis for Multiple Textures
 % In this section we look at how well the texture synthesis algorithm
 % works across multiple textures of a carpet, flakes, seeds, and plastic
 % tiles. We show the pairs of input textures with their respective
 % synthesized textures below.
 
 funcImg = imread('/home/weinman/courses/CSC262/images/texture/carpet002-inca-100dpi-00.bmp');
 funcImg1 = imread('/home/weinman/courses/CSC262/images/texture/flakes001-inca-100dpi-00.bmp');
 funcImg2 = imread('/home/weinman/courses/CSC262/images/texture/seeds005-inca-100dpi-00.bmp');
 funcImg3 = imread('/home/weinman/courses/CSC262/images/texture/plastic001-inca-100dpi-00.bmp');

 figure;
 subplot(2,2,1);
 imshow(rgb2gray(funcImg),[]);
 title('Carpet Image');
 subplot(2,2,2);
 imshow(rgb2gray(funcImg1),[]); 
 title('Flakes Image');
 subplot(2,2,3);
 imshow(rgb2gray(funcImg2),[]); 
 title('Seeds Image');
 subplot(2,2,4);
 imshow(rgb2gray(funcImg3),[]);
 title('Plastic Image');
 
 figure;
 Y = texturesyn(funcImg, 300,300);
 subplot(2,2,1);
 imshow(Y, []);
 title('Synthesized Carpet Image');
 
 Y1 = texturesyn(funcImg1, 300,300);
 subplot(2,2,2);
 imshow(Y1, []);
 title('Synthesized Flakes Image');
 
 Y2 = texturesyn(funcImg2, 300,300);
 subplot(2,2,3);
 imshow(Y2, []);
 title('Synthesized Seeds Image');
 
 Y3 = texturesyn(funcImg3, 300,300);
 subplot(2,2,4);
 imshow(Y3, []);
 title('Synthesized Plastic Image');
 
 %%
 % Looking at the pairs of input texture images and corresponding output
 % synthesized texture images, it is clear that the histogram equalization
 % method is working uniquely to each texture. The synthesized carpet image
 % has small defined waves throughout the image like the input texture, the
 % synthesized flakes image has small, localized jagged edges like the
 % input texture, and the synthesized seeds image has a blob-like
 % arrangement of textures, similar to the blob-like seed structures in the
 % input image. 

 %%
% However, this algorithm is not perfect in texture synthesis. In the
% synthesized carpet image, there are larger winding waves of pixels that
% appear lighter or darker. In contrast, the original image has a general
% gradient of lighter to darker pixels moving down the rows in the image.
% This shows that the algorithm is not the most effective when there is a
% larger effect on the texture across the entire image (i.e., when the
% texture is inconsistent across the entire image). Additionally, the seeds
% and plastic texture synthesized images appear less realistic, likely
% because of the larger shapes present in these textures, such as the bean
% structure and the square shapes. This observation shows the weakness of
% the algorithm in recreating larger object textures.

 %% Conclusion
 % In this lab, we explored how to recreate a texture from an input image
 % by starting with a white noise image and repeatedly performing histogram
 % equalizations on the noise image to appear like the input image
 % histograms. Using a similar method to Heeger and Bergen’s texture
 % synthesis algorithm, we applied histogram equalizations for each band in
 % a steerable pyramid of the white noise image to make the texture
 % synthesis more realistic. We found that the texture synthesis is fairly
 % accurate in resembling the general appearance of the texture; however,
 % the algorithm is not perfect for matching small-scale details in texture
 % or for matching larger-scale structures of textures. While this
 % algorithm creates recognizable patterns matching an input texture, for
 % highly accurate texture synthesis, we think an algorithm like Bonet and
 % Viola may be more appropriate.

%% Acknowledgement
% The corresponding code is provided by professor Weinman in CSC-262
% Texture Synthesis Lab.
% The Texture Image is from the University of Oulu Texture Database
% "Outex."
