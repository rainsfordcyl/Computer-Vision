function textureSynImg = texturesyn(inputImg, N, M)
%TEXTURESYN returns a synthesized N by M texture image based on inputImg.
%   This function works by repeated performing histogram equalization on
%   the layers of a steerable pyramid of an N x M white noise image to make
%   the noise image match the texture of the inputImg.
%PARAMETERS
%   N specifies the number of rows (vertical size) of the output image.
%
%   M specifies the number of columns (horizontal size) of the output
%   image.
%
%   inputImg is the original texture image that the function synthesizes
%   the texture based out of.
%OUTPUT
%   textureSynImg is the returned synthesized texture output image whose 
%   size is N by M.

 % Convert inputImg to grayscale and of double values
 img = rgb2gray(im2double(inputImg));

 % number of bins to use in creating histograms
 bins = 256;
 binEdges = linspace(0,1,bins);
 
 % number of layers in the steerable pyramid
 scales = 5;
 % error threshold for when to stop texture synthesis while loop
 threshold = 0.05;
 
 % create the noise image based on M and N value
 grayImg = zeros(N, M) + 0.5;
 noiseImg = imnoise(grayImg, 'gaussian');
 
 % create the histogram for the input image
 originalHistogram = histc(img(:), binEdges);
 
 % first equalization of synthesized image based on input image histogram
 equalizedImg = histeq(noiseImg,originalHistogram);
 
 % this while loop continually equalizes the synthesized image steerable
 % pyramid bands to match the bands of the input image steerable pyramid
 % until the differnce is smaller than threshold we set.
 while true

 % create the steerable pyramid for the original image
 [steerPyrOriginal, OriginalImgindices] = buildSFpyr(img, scales);
 
 % create the steerable pyramid for the texture synthesis image
 [steerPyrSynthesized, SynthesizedImgindices] = buildSFpyr(equalizedImg, scales);

 resultPyr = steerPyrSynthesized;
 
 % for loop that iterates each band of the steerable pyramid
 for i=1:size(SynthesizedImgindices,1)
     % get band i from the original image pyramid
     pyrBandOriginal = pyrBand(steerPyrOriginal,...
         OriginalImgindices,...
         i);
     % get band i from the synthesized image pyramid
     pyrBandSynthesized = pyrBand(steerPyrSynthesized,...
         SynthesizedImgindices,...
         i);
     % get the max and min value from the band
     bandMax = max(pyrBandOriginal(:));
     bandMin = min(pyrBandOriginal(:));
     % adjust the synthesized image band value in the range of 0 to 1 
     pyrBandSynthesizedAdj = imadj(pyrBandSynthesized,...
        [bandMin bandMax],...
        [0 1]); 
     % adjust the original image band value in the range of 0 to 1 
     pyrBandOriginalAdj = imadj(pyrBandOriginal,...
        [bandMin bandMax],...
        [0 1]); 
     % create the histogram of the original image band
     originalBandHistogram = histc(pyrBandOriginalAdj(:), binEdges);
    
     % adjust the synthesized image band histogram to match the original
     % image band historgam
     adjustedSynthesizedImgBand = histeq(pyrBandSynthesizedAdj,originalBandHistogram);
     % reset the pixel value of the synthesized image band
     transformedSynthesizedImgBand = imadj(adjustedSynthesizedImgBand,...
        [0 1],...
        [bandMin bandMax]); 
     
    % get indices for the band to update
    bandIndex = pyrBandIndices(SynthesizedImgindices, i);
    % copy the recovered synthesized band to a steerable pyramid variable
    resultPyr(bandIndex:(bandIndex + size(transformedSynthesizedImgBand(:), 1) - 1))...
        = transformedSynthesizedImgBand(:);
 end
 
 % reconstruct the adjusted synthesized pyramid.
 adjustedSynthesizedImg = reconSFpyr(resultPyr,SynthesizedImgindices);
 
 % adjust the synthesized image to match the histogram of the original
 % image
 histEqualizedAdjustedSynthesizedImg = ...
     histeq(adjustedSynthesizedImg,originalHistogram);
 
 % check and compare the error between the two image, loop again if
 % threshold isn't reached
 % Reference: the code below is received from professor Weinman in Texture
 % Synthesis Lab Manual.
 if ((mean(abs(histEqualizedAdjustedSynthesizedImg(:)))...
         - mean(abs(equalizedImg(:)))) ...
         < threshold)
     break;
 end

 % update the synthesized image outside the while loop
 equalizedImg = histEqualizedAdjustedSynthesizedImg;

 end
 % set the output to be the final synthesized image
 textureSynImg = histEqualizedAdjustedSynthesizedImg;
 
end

